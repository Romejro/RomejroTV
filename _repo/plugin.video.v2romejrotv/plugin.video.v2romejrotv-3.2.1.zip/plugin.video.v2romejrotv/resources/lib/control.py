# control.py
import xbmcaddon

addon = xbmcaddon.Addon()

def setting(id):
    return addon.getSetting(id)

def setSetting(id, value):
    addon.setSetting(id, value)
