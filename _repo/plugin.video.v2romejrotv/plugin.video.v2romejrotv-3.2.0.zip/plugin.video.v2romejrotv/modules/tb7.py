# -*- coding: utf-8 -*-
import sys
import os.path

import re
from datetime import datetime

from urllib.parse import parse_qsl, urlencode, unquote, quote
from html import unescape

import requests

import urllib3  # potrzebne, aby poniższa linijka zadziałała
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from resources.lib.cmf3 import parseDOM
from resources.lib.cmf3 import replaceHTMLCodes
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

addon = xbmcaddon.Addon(id='plugin.video.v2romejrotv')
win = xbmcgui.Window(xbmcgui.getCurrentWindowId())

base_url = sys.argv[0]
old_player_method = 'false'
custom_headers = True 
use_second_line = 'false'
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:], True))
BLACKLIST_PATTERNS = [
    r'onlyfans', 
    r'xxx', 
    r'sex', 
    r'porn',
    r'fuck',
    r'blowjob',
    r'horny',
    r'khalifa',
    r'anal',
    r'x[\W_]*x[\W_]*x',  # np. X-X-X
]
def log(msg, level=1):
    xbmc.log(f'[tb7 player] {msg}', level)
    
def build_url(query):
    query = query if query else {'action': 'nothing'}  # opcjonalnie
    return base_url + '?' + urlencode(query)
class cache:
    def cache_get(key):
        return {"value": win.getProperty(key)}

    def cache_insert(key, value):
        win.setProperty(key, value)
        
def months_to_miesiace(text, short=0):
    months = {
        "monday": ["poniedziałek", "pon"],
        "tuesday": ["wtorek", "wt"],
        "wednesday": ["środa", "śr"],
        "thursday": ["czwartek", "czw"],
        "friday": ["piątek", "pt"],
        "saturday": ["sobota", "sob"],
        "sunday": ["niedziela", "niedz"],
    }
    months3 = {k[:3]: v for k, v in months.items()}
    return re.sub(
        r"[a-z]+",
        lambda w: months[w.group().lower()][short]
        if w.group().lower() in months
        else months3[w.group().lower()[:3]][1]
        if w.group().lower()[:3] in months3
        else w.group(),
        text,
        flags=re.I,
    )
def convert_size_to_bytes(size):
    suffixes = ("", "k", "m", "g", "t")
    multipliers = {'{}b'.format(l) : 1024**i for i,l in enumerate(suffixes) }
    bytes = re.sub(
        r"(\d+(?:[.,]\d+)?)\s?({})".format("|".join(x+"b" for x in suffixes)),
        lambda m: str( float(m.group(1).replace(',', '.')) * multipliers[m.group(2).lower()] ),
        size,
        flags=re.I)
    try:
        return int(float(bytes))
    except ValueError:
        return 0

def clean_text(text):
    """Usuń wszystkie tagi HTML i zbędne spacje, zwróć małe litery"""
    text = unescape(text)                 # dekodowanie encji HTML
    text = re.sub(r'<.*?>', '', text)     # usuwanie tagów HTML
    return text.strip().lower()
def build_url(query):
    query = query if query else {'action': 'nothing'}  # opcjonalnie
    return base_url + '?' + urlencode(query)


counter = 0

def add_item(name, image, folder, payload, IsPlayable='true', cm=None, returnAsTuple=False):
    global counter
    counter += 1

    list_item = xbmcgui.ListItem(label=name)

    if IsPlayable == 'true':
        infoLabels={
            # 'title': name,  # nie wiem, czy to w ogóle jest to potrzebne
            # 'sorttitle': name,  # do czego to ?
            'size': convert_size_to_bytes(payload.get('size', '')),  # do sortowania potrzebne
            'count': counter,  # do sortowania potrzebne
            }
        list_item.setInfo(type='video', infoLabels=infoLabels)  # may be deprecated in future Kodi versions 

        # nowszy sposób (nie wiem od którego Kodi)
        # info_tag = list_item.getVideoInfoTag()
        # info_tag.setMediaType('video')
        # info_tag.setTitle(name)
        # brak na razie metody do size i count

    list_item.setArt({
        'thumb': image,
        'poster': image,
        'banner': image,
        'fanart': image})

    if not folder and not old_player_method:
    #if not folder:
        list_item.setProperty('IsPlayable', IsPlayable)  # jak nie jest 'true', to przy próbie odtwarzania "handle" jest "-1"

    if cm:
        list_item.addContextMenuItems(cm)

    if returnAsTuple:
        return (build_url(payload), list_item, folder)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url(payload), listitem=list_item, isFolder=folder)
class TB7:
    def __init__(self):
        self.session = requests.session()
        self.username = addon.getSetting('tb7.username')
        self.password = addon.getSetting('tb7.password')
        self.headers = {}
        if addon.getSetting('headers.mode') == 'przeglądarka':
            self.headers = {"Connection": "keep-alive", "Upgrade-Insecure-Requests": "1",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36+SOSNF-CS20.10.5/200R0CVLCI-2BDE4C4A6B67444C",
                            "DNT": "1",
                            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
                            "Accept-Language": "pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7", }
        elif addon.getSetting('headers.mode') == 'VLC':
            self.headers = {"User-Agent": "VLC/3.0.20 LibVLC/3.0.20"}
        elif addon.getSetting('headers.mode') == 'własny':
            self.headers = {"User-Agent": addon.getSetting('custom_user_agent')}
        # log(f'{self.headers=!r}')
        self.base_url = "https://tb7.pl"
        self.search_url = "mojekonto/szukaj"
        self.VIDEO_EXTENSIONS = ("avi", "mkv", "mp4", "mpg", ".ts")  # allowed extensions for video files


    def login_cache(fnc):
        """verify if user is logged"""
        def decorator(self, *args, **kwargs):
            try:
                # próba pobrania ciasteczka z cache
                cookie = cache.cache_get('tb7_cookie')['value']
                if not cookie:
                    raise Exception()
                self.headers.update({'Cookie': cookie})
            except Exception:
                # brak ciasteczka w cache
                log('z powodu braku ciasteczka potrzeba ponownego zalogowania')
                self.login()  # tu działa ponowne logowanie
            # kontrola, czy zalogowany
            response = self.session.get(self.base_url, headers=self.headers, verify=False).text
            if "yloguj" not in response:
                log('potrzeba ponownego zalogowania')
                self.headers.pop('Cookie', None)
                self.login()
            fnc(self, *args, **kwargs)
        return decorator


    def login(self):
        if not (self.username and self.password):
            log(f'Brak danych do zalogowania')
            xbmcgui.Dialog().ok('tb7 Player', 'Podaj dane logowania w ustawieniach wtyczki.')
            sys.exit()
        else:
            log(f'próba zalogowania')
            session = requests.session()
            session.post(f'{self.base_url}/login', verify=False, allow_redirects=False, data={
                'login': self.username,
                'password': self.password,
                })
            # sprawdzenie, czy logowanie przebiegło pomyślnie
            response = session.get(self.base_url, headers=self.headers).text
            if "yloguj" in response:
                log(f'Zalogowano poprawnie')
                cookie = session.cookies.get_dict()  # odczytanie ciasteczka
                cookie_string = "; ".join([str(x) + "=" + str(y) for x, y in cookie.items()])  # przerobienie na string
                cache.cache_insert('tb7_cookie', str(cookie_string))  # zapisanie ciasteczka do cache
                limit_info = self.remaining_limit(response)
                xbmcgui.Dialog().notification('TB7', (f'Zalogowano poprawnie.\nMasz [B]{limit_info}[/B] transferu do wykorzystania'))
            else:
                log(f'Logowanie nieudane')
                xbmcgui.Dialog().ok("Błąd", "Logowanie nieudane, sprawdź dane konta w ustawieniach wtyczki")
                # print(f'{self.username=!r} {self.password=!r}')  # OSTROŻNIE!
                cache.cache_insert('tb7_cookie', '')
                sys.exit()
            self.session = session
            return session


    


    @login_cache
    def library(self):
        try:
            response = self.session.get(
                f'{self.base_url}/mojekonto/pliki',
                headers=self.headers,
                verify=False
            )
    
            tables = parseDOM(response.text, 'table', attrs={'class': 'list'})
            if not tables:
                xbmcgui.Dialog().ok('TB7', 'Twoja biblioteka jest pusta')
                return
    
            tbody = parseDOM(tables[0], 'tbody')
            rows = parseDOM(tbody, 'tr')
    
            entries = []
    
            for row in rows:
                cells = parseDOM(row, 'td')
                if len(cells) < 4:
                    continue
    
                link = parseDOM(cells[1], 'a', ret='href')[0]
    
                filename = parseDOM(cells[1], 'a')[0].replace('.../', '')
                filename = unescape(unquote(filename))
    
                expire = cells[3]
                try:
                    expire = datetime.strptime(
                        expire, "%H:%M %d.%m.%Y"
                    ).strftime("%A %H:%M")
                except Exception:
                    pass
    
                expire = months_to_miesiace(expire, short=0)
                expire = re.sub(r"0(\d)(?=:\d\d)", r"\1", expire).title()
    
                label = f"{filename} | wygasa: {expire}"
    
                entries.append({
                    "label": label,
                    "link": link,
                    "filename": filename
                })
    
            if not entries:
                xbmcgui.Dialog().ok('TB7', 'Twoja biblioteka jest pusta')
                return
    
            sel = xbmcgui.Dialog().select(
                "TB7 – Twoja biblioteka",
                [e["label"] for e in entries]
            )
    
            if sel == -1:
                return
    
            selected = entries[sel]
    
            # ▶️ ODTWARZANIE
            xbmc.Player().play(selected["link"])
    
        except Exception as e:
            xbmcgui.Dialog().ok('TB7 – błąd', str(e))
    def get_library_name_to_link_map(self):
        """
        Zwraca słownik: nazwa pliku -> link w bibliotece
        """
        result = {}
        try:
            response = self.session.get(f'{self.base_url}/mojekonto/pliki', headers=self.headers, verify=False).text
            tables = parseDOM(response, 'table', attrs={'class': 'list'})
            if not tables:
                return result
            tbody = parseDOM(tables[0], 'tbody')
            rows = parseDOM(tbody, 'tr')
            for row in rows:
                cells = parseDOM(row, 'td')
                if len(cells) < 2:
                    continue
                name = parseDOM(cells[1], 'a')[0].replace('.../', '')
                name = unescape(unquote(name))
                link = parseDOM(cells[1], 'a', ret='href')[0]
                result[self.normalize_filename(name)] = link
        except:
            pass
        return result


    
    def get_library_filenames(self):
        response = self.session.get(
            f'{self.base_url}/mojekonto/pliki',
            headers=self.headers,
            verify=False
        ).text
    
        table = parseDOM(response, 'table', attrs={'class': 'list'})
        if not table:
            return set()
    
        rows = parseDOM(table[0], 'tr')
        filenames = set()
    
        for row in rows:
            cells = parseDOM(row, 'td')
            if len(cells) < 2:
                continue
    
            a = parseDOM(cells[1], 'a')
            if not a:
                continue
    
            name = a[0].replace('.../', '')
            name = unescape(unquote(name))
            name = self.normalize_filename(name)
    
            filenames.add(name)
    
        return filenames
    def normalize_filename(self, name):
        name = name.lower()
        name = re.sub(r'\s+', '.', name)
        name = re.sub(r'[^\w\.\-]', '', name)
        return name

    def is_in_library(self, link):
        response = self.session.get(
            f'{self.base_url}/mojekonto/pliki',
            headers=self.headers,
            verify=False
        ).text
    
        return link in response

    def play(self):
        check_link_before_play = addon.getSetting('check_link_before_play') == 'true'

        if check_link_before_play:
            xbmcgui.Dialog().notification('TB7', (f'sprawdzanie linku ...'), sound=False, time=1000)
            log('sprawdzanie linku przed odtworzeniem')

        link = params.get('link', None)

        link = link.replace("%2F", "-")  # fix na "/" w nazwie
        #log(f' {link=!r}')
        """
        if '/pobieramy/' in link:
          link = link.rpartition('/')[0]
          # log(f' {link=!r}')
        """

        link0 = link
        log(f'{link0=!r}')

        if check_link_before_play:
            response = self.session.get(link, headers=self.headers, verify=False, allow_redirects=False)
            log(f' {response.status_code=!r}')
            if response.status_code == 200 and '/pobieramy/' in link:
                if 'dla podanego linka Premium' in response.text:
                    xbmcgui.Dialog().ok('Error', 'Osiągnięto limit pobrań dla wybranego linka.')
                else:
                    xbmcgui.Dialog().ok('Error', 'Ważność linku wygasła.')
                params.update({'action': ''})
                return
            if response.status_code >= 400:
                xbmcgui.Dialog().notification('TB7', (f'Serwer zgłosił błąd nr {response.status_code}'), xbmcgui.NOTIFICATION_ERROR)
                responseHTML = response.text.replace("\r", "").replace("\n", "").replace("\t", "")
                log(f' {responseHTML=!r}')
                if addon.getSetting('try_start_play_despite_server_error') == 'false':  # bo może zewnętrzny player nie dostanie błędu odmowy
                    params.update({'action': ''})
                    return
            if response.status_code == 302:
                link = response.headers['Location']
                try:
                    link = link.encode('latin1').decode('utf8')  # aby było czytelniej w logach
                except Exception:
                    pass
                log(f' {link=!r}')

                if 'download_token=' in link and 'wrzucaj.pl/' in link and params.get('direct') != '1' and '/pobieramy/' in link0:
                    # to avoid error will try reset token
                    link = re.sub(r'(?<=//)\w+?\.(wrzucaj\.pl/)', r'\1file/', link)
                    link = re.sub(r'\&?download_token=[^&]*', '', link).rstrip('?')
                    # log(f' {link=!r}')

                if True:
                    xbmc.sleep(100)
                    response = self.session.get(link, headers=self.headers, verify=False, allow_redirects=False, stream=True)
                    log(f' {response.status_code=!r}') if response.status_code != 200 else ''
                    if response.status_code == 200:
                        if 'text' in response.headers['Content-Type']:
                            responseHTML = response.text.replace("\r", "").replace("\n", "").replace("\t", "")
                            log(f' {responseHTML=!r}')
                        else:
                            log(f" {response.headers['Content-Type']=!r}")
                            response.close()  # aby nie wczytywać danych
                    elif response.status_code >= 400:
                        xbmcgui.Dialog().notification('TB7', (f'Serwer zwrócił błąd nr {response.status_code}'), xbmcgui.NOTIFICATION_ERROR)
                        responseHTML = response.text.replace("\r", "").replace("\n", "").replace("\t", "")
                        log(f' {responseHTML=!r}')
                        if addon.getSetting('try_start_play_despite_server_error') == 'false':  # bo może zewnętrzny player nie dostanie błędu odmowy
                            params.update({'action': ''})
                            return
                    elif response.status_code == 302:
                        link = response.headers['Location']
                        try:
                            link = link.encode('latin1').decode('utf8')  # aby było czytelniej w logach
                        except Exception:
                            pass
                        log(f' {link=!r}')

                        xbmc.sleep(100)
                        response = self.session.get(link, headers=self.headers, verify=False, allow_redirects=False, stream=True)
                        log(f' {response.status_code=!r}') if response.status_code != 200 else ''
                        if response.status_code == 200:
                            if 'text' in response.headers['Content-Type']:
                                responseHTML = response.text.replace("\r", "").replace("\n", "").replace("\t", "")
                                log(f' {responseHTML=!r}')
                            else:
                                log(f" {response.headers['Content-Type']=!r}")
                                response.close()  # aby nie wczytywać danych
                        elif response.status_code >= 400:
                            xbmcgui.Dialog().notification('TB7', (f'Serwer zwrócił błąd nr {response.status_code}'), xbmcgui.NOTIFICATION_ERROR)
                            responseHTML = response.text.replace("\r", "").replace("\n", "").replace("\t", "")
                            log(f' {responseHTML=!r}')
                            if addon.getSetting('try_start_play_despite_server_error') == 'false':  # bo może zewnętrzny player nie dostanie błędu odmowy
                                params.update({'action': ''})
                                return
                        else:
                            response.close()  # bo stream=True (choć chyba już nie potrzebne w tym miejscu)

                    else:
                        response.close()  # bo stream=True (choć chyba już nie potrzebne w tym miejscu)

            if addon.getSetting('link_before_redirection') == 'true':
                link = link0
                log(f'do odtwarzacza idze pierwszy link (przed przekierowaniem)')

            if xbmc.getCondVisibility('Window.IsActive(notification)'):
                #xbmc.executebuiltin('Dialog.Close(notification,true)')
                pass

            #log(f' {link=!r}')
            xbmc.sleep(100)

        strip_headers_from_link = addon.getSetting('strip_headers_from_link') == 'true'
        if custom_headers:
            # potrzebne, gdy musimy przesłać innego useragenta, bo domyślny jest blokowany przez serwer
            if not strip_headers_from_link:
                link = link + f"|User-Agent={quote(self.headers.get('User-Agent', ''))}&verifypeer=false"  # nie zadziała odtwarzanie przez VLC (przynajmniej w tej wersji Kodi oraz w tej versi VLC)
                pass
            """
            problemy to:
             - do VLC przekazywany cały string, łącznie z tym co jest po znaku | (choć to nie jest częścią adresu, a jedynie jedynym sposobem przekazania dalej (do CURL) headerów)
             - nie ma możliwości stwierdzenia, czy użytkownik wybrał opcję "Odtwórz, używając ..." dla danej pozycji
             - VLC nie odrzuca tego, co jest po znaku |
             Czyli KODI powinno zostać poprawione
            """

        log('rozpoczynanie odtwarzania')
        #if old_player_method or addon_handle < 0 or params.get('di2rect') == '1':  # warunek params.get('direct') do usunięcia
        if old_player_method or addon_handle < 0:  # musi korespondować z linią 98
        #if addon_handle < 0:  # musi korespondować z linią 99
            log(f"xbmc.Player().play() is use")
            xbmc.Player().play(link)  # ale nie może być ustawiony IsPlayable na True (linia 98) przy tworzeniu elementów folderu, bo powstaje konfilkt z setResolvedUrl
        else:
            list_item = xbmcgui.ListItem(path=link)

            if params.get('direct') == '1':  # zauważyłem, że w takim przypadku nie są przekazywane dane (choć w poprzedniej metodzie były), więc dodaje ręcznie
                info_tag = list_item.getVideoInfoTag()
                #info_tag.setMediaType('video')  # to raczej opcjonalne w tym kontekście, bo linia wyżej mówi, że to video
                info_tag.setTitle(params.get('filename', ''))
                # info_tag.setPlot(link0.replace('_', ' '))  # tylko, że linki są długie i brzydko wyglądają

            xbmcplugin.setResolvedUrl(addon_handle, True, list_item)  # przekazanie danych do wewnętrznego (KODI) lub zewnętrznego odtwarzacza


    @login_cache
    def search(self):
        # 1. pobranie frazy
        search = params.get('search') or win.getProperty('tb7player.search')
    
        if not search:
            keyb = xbmc.Keyboard('', 'Wpisz frazę do wyszukania')
            keyb.doModal()
            if not keyb.isConfirmed():
                return
            search = keyb.getText().strip()
    
        if not search:
            return
    
        win.setProperty('tb7player.search', search)
    
        # 2. wykonanie search
        self.login()  # upewnij się że jest zalogowany
        data = {'type': '1', 'search': search}
        response = self.session.post(f'{self.base_url}/{self.search_url}', headers=self.headers, data=data).text
    
        # 3. pobranie pierwszej strony wyników
        page = 1
        response = self.session.get(f'{self.base_url}/{self.search_url}/{page}', headers=self.headers).text
        rows = parseDOM(response, 'tr')
    
        if not rows:
            xbmcgui.Dialog().ok('TB7', f'Brak wyników dla:\n[B]{search}[/B]')
            return
    
        # 4. użycie oryginalnego extract_items() żeby zbudować listę
        items = []

        for row in rows:
            try:
                nazwa = parseDOM(row, 'label')[0]
                if "<a " in nazwa.lower():
                    nazwa = parseDOM(nazwa, "a")[0]
        
                # link i filename
                link = parseDOM(row, 'input', ret='value')[0]
                filename = unescape(unquote(nazwa)).strip()
        
                # filtr rozszerzeń wideo
                if not any(filename.lower().endswith(ext.lower()) for ext in self.VIDEO_EXTENSIONS):
                    continue
        
                # filtr blacklist regex
                check_name = re.sub(r'[^a-z0-9]', ' ', filename.lower())  # wszystkie znaki nie-alfanumeryczne na spacje
                if any(re.search(pattern, check_name) for pattern in BLACKLIST_PATTERNS):
                    continue  # pomiń pliki z czarnej listy
        
                size = parseDOM(row, 'td')[3] if len(parseDOM(row, 'td')) > 3 else ''
                host = parseDOM(row, "td")[1] if len(parseDOM(row, 'td')) > 1 else ''
        
                items.append({
                    'label': filename,
                    'size': size,
                    'host': host,
                    'link': link
                })
        
            except Exception:
                continue

    
        if not items:
            xbmcgui.Dialog().ok('TB7', f'Brak wyników dla:\n[B]{search}[/B]')
            return
    
        
        # 5. dialog wyboru źródła z opcją korekty wyszukiwania
        labels = [
            "[TB7] - Koryguj wyszukiwanie",
            "[TB7] - Moja Biblioteka",
            "   [COLOR gray]   --------------------------Wyniki wyszukiwania--------------------------  [/COLOR]"
        ] + [
            f"{i['label']}  [COLOR gray]|{i['size']}|{i['host']}[/COLOR]"
            for i in items
        ]
        
        # nagłówek z wyszukiwaną frazą
        dialog_title = f"Szukasz: {search}"
        while True:
            idx = xbmcgui.Dialog().select(dialog_title, labels)
            
            if idx == -1:
                return  # użytkownik anulował
            if idx == 2:
                
                continue  # nic nie rób, to separator
            if idx == 0:
                # opcja "Koryguj wyszukiwanie" z domyślną wartością
                keyb = xbmc.Keyboard(search, 'Skoryguj wyszukiwanie')
                keyb.doModal()
                if keyb.isConfirmed() and keyb.getText().strip():
                    new_search = keyb.getText().strip()
                    win.setProperty('tb7player.search', new_search)
                    params['search'] = new_search
                    self.search()
                return
            if idx == 1:
                # opcja "Moja Biblioteka"
                self.library()  # wywołaj funkcję biblioteki
                return
            
            # użytkownik wybrał źródło
            real_idx = idx - 3  # odejmujemy 2, bo pierwsze dwie pozycje to opcje specjalne
            if 0 <= real_idx < len(items):
                item = items[real_idx]
                self.add_to_library(
                    item['link'], item['label'], item['size'], item['host']
                )
            
            
            

    def extract_items(self, rows, page=1):
        items = []
        for row in rows:
            try:
                # pobierz link i filename
                link = parseDOM(row, 'input', ret='value')[0]
                filename = unescape(unquote(link)).strip()
    
                # zamień wszystkie znaki niealfanumeryczne na spacje, lowercase
                check_name = re.sub(r'[^a-z0-9]', ' ', filename.lower())
    
                # filtr blacklist regex
                if any(re.search(pattern, check_name) for pattern in BLACKLIST_PATTERNS):
                    continue
    
                # filtr rozszerzeń wideo
                if not any(filename.lower().endswith(ext.lower()) for ext in self.VIDEO_EXTENSIONS):
                    continue
    
                # pozostałe dane
                tds = parseDOM(row, 'td')
                size = tds[3] if len(tds) > 3 else ''
                host = tds[1] if len(tds) > 1 else ''
    
                label = f'{filename} | {size} | {host}'
                items.append({'label': label, 'link': link, 'filename': filename, 'size': size, 'host': host})

            except Exception:
                continue
    
        if not items:
            xbmcgui.Dialog().ok("TB7", "Brak plików wideo dla szukanej frazy")
            return
    
        # pokaz dialog select
        labels = [i['label'] for i in items]
        sel = xbmcgui.Dialog().select("Wybierz źródło TB7", labels)
        if sel == -1:
            return  # użytkownik anulował
    
        # po wyborze pokaz okno z pytaniem
        chosen = items[sel]
        filename = chosen['filename']
        host = chosen['host']
        size = chosen['size']
        link = chosen['link']
    
        ok = xbmcgui.Dialog().yesno(
            "TB7",
            f"Czy chcesz wypożyczyć / dodać do biblioteki?\n\n"
            f"[B]{filename}[/B]\n"
            f"Rozmiar: [B]{size}[/B]\n"
            f"Serwer: [B]{host}[/B]"
        )
        if not ok:
            return
    
        # wywołanie istniejącej funkcji add_to_library
        self.add_to_library(link, filename, size, host)

    # def extract_items(self, rows, page=1):
    #     # budowanie listy etykiet i danych
    #     items_data = []
    
    #     for row in rows:
    #         try:
    #             nazwa = parseDOM(row, 'label')[0]
    #             if "<a " in nazwa.lower():
    #                 nazwa = parseDOM(nazwa, "a")[0]
    
    #             if nazwa[-3:] not in self.VIDEO_EXTENSIONS:
    #                 continue
    
    #             link = parseDOM(row, 'input', ret='value')[0]
    #             size = parseDOM(row, 'td')[3]
    #             host = parseDOM(row, 'td')[1]
    #             filename = unescape(unquote(nazwa))
    
    #             items_data.append({
    #                 'label': f"{filename} | {size} | {host}",
    #                 'link': link,
    #                 'filename': filename,
    #                 'size': size,
    #                 'host': host
    #             })
    
    #         except Exception as e:
    #             continue
    
    #     # jeśli brak elementów
    #     if not items_data:
    #         xbmcgui.Dialog().ok('TB7', 'Brak plików wideo dla szukanej frazy')
    #         return
    
    #     # wybór elementu przez dialog.select
    #     labels = [i['label'] for i in items_data]
    #     sel = xbmcgui.Dialog().select('Wybierz źródło TB7', labels)
    #     if sel == -1:
    #         return  # użytkownik anulował
    
    #     # pobranie wybranego elementu
    #     selected = items_data[sel]
    
    #     # wywołanie add_to_library bezpośrednio
    #     params['link'] = selected['link']
    #     params['filename'] = selected['filename']
    #     params['size'] = selected['size']
    #     params['host'] = selected['host']
    #     self.add_to_library()


    def get_real_link_from_library(self, link):
        """
        Pobiera AKTYWNY link do odtwarzania z biblioteki TB7
        """
        try:
            xbmc.log(f"[TB7 REAL] request link={link}", xbmc.LOGWARNING)
    
            # NIE allow_redirects – chcemy złapać Location
            response = self.session.get(
                link,
                headers=self.headers,
                verify=False,
                allow_redirects=False
            )
    
            xbmc.log(
                f"[TB7 REAL] status={response.status_code} headers={response.headers}",
                xbmc.LOGWARNING
            )
    
            # TB7 ZAWSZE zwraca 302
            if response.status_code in (301, 302):
                real_link = response.headers.get('Location')
                if real_link:
                    xbmc.log(f"[TB7 REAL] resolved={real_link}", xbmc.LOGWARNING)
                    return real_link
    
            xbmc.log("[TB7 REAL] brak przekierowania", xbmc.LOGWARNING)
            return None
    
        except Exception as e:
            xbmcgui.Dialog().ok('TB7 – błąd', str(e))
            return None



    @login_cache
    def add_to_library(self, link, filename, size, host):
        from main import PlayVid
        
        # link = params.get('link')
        
        xbmc.log(f"[TB7 ADD] link={link}", xbmc.LOGWARNING)
        # Normalizujemy nazwę pliku
        filename = self.normalize_filename(filename)

        # Pobierz już istniejące pliki w bibliotece z mappingiem nazwa -> link
        existing_files = self.get_library_filenames()  # zakładam, że to lista nazw
        library_links = self.get_library_name_to_link_map()  # nazwa -> link w bibliotece
    
        if filename in existing_files:
            # Pobierz link z biblioteki
            lib_link = library_links.get(filename)
            if lib_link:
                # Zapytaj użytkownika, czy chce odtworzyć
                ret = xbmcgui.Dialog().yesno(
                    'TB7',
                    f'Plik "{filename}" już istnieje w bibliotece.\nCzy chcesz go odtworzyć?'
                )
                if ret:
                    real_link = self.get_real_link_from_library(lib_link)
                    xbmc.log(f"[TB7 ADD] real_link={real_link}", xbmc.LOGWARNING)
                    if real_link:
                        PlayVid(
                            real_link,
                            adaptive=True
                        )
                        xbmc.log(f"[TB7 ADD] real_link={real_link}", xbmc.LOGWARNING)
            return

        

        # host = params.get('host', 'nieznany')
        # size = params.get('size', 'nieznany')
        # filename = params.get('filename', '')

        filename = unquote(filename)
        filename = unescape(filename)
        filename = self.prepare_filename_to_display(filename)

        user_accepts = xbmcgui.Dialog().yesno(
            'Wymagane potwierdzenie',
            (
                f'[LIGHT]Czy potwierdzasz "wypożyczenie" ?[/LIGHT]\n'
                f'[LIGHT][B][I]{filename}[/I][/B][/LIGHT]\n'
                f' rozmiar: [B]{size}[/B]'
                f', serwer: [B][I]{host}[/I][/B]'
            ),
        )
        if not user_accepts:  # rezygnacja
            return

        # test czy link aktywny
        data = {'step': '1', 'content': link}
        response = self.session.post(f'{self.base_url}/mojekonto/sciagaj', data=data, headers=self.headers).text

        if ' value="Wgraj linki"' not in response:
            xbmcgui.Dialog().ok('Błąd', f'Link nieaktywny')
            return

        limit_info = self.remaining_limit(response)

        if "ymagane dodatkowe" in response:
            xbmcgui.Dialog().ok('Brak środków', f'Brak wystarczającego transferu. \n[COLOR gray](aktualnie posiadasz [B]{limit_info}[/B])[/COLOR]')
            return None

        # do testów
        # return (False if not xbmcgui.Dialog().yesno("TB7", (f"Aktywny link to \n[LIGHT][B][I]{(active_url)}[/I][/B][/LIGHT]\nCzy kontynuować?") ) else True)

        # próba dodania źródła do biblioteki
        data = {'0': 'on', 'step': '2'}
        response = self.session.post(f'{self.base_url}/mojekonto/sciagaj', data=data, headers=self.headers).text

        div = parseDOM(response, "div", attrs={"class": "download"})
        # try:
        #     link2 = parseDOM(div, "a", ret="href")[1]
        #     size2 = div[1].split("|")[-1].strip()
        # except Exception:
        #     if "Nieaktywne linki" in response:
        #         xbmcgui.Dialog().notification("TB7", ("Link okazał się nieaktywny"))
        #         return
        #     else:
        #         # xbmcgui.Dialog().notification("TB7", ("Wystąpił jakiś błąd. \nMoże link już nieaktywny? Albo brak transferu."), xbmcgui.NOTIFICATION_ERROR)
        #         xbmcgui.Dialog().ok('Brak środków', f'Brak wystarczającego transferu. \n[COLOR gray](aktualnie posiadasz [B]{limit_info}[/B])[/COLOR]')
        #         return

        win.setProperty('tb7_player_wasAdded', link)
        self.library()


    @login_cache
    def check_limit(self):
        response = self.session.get(self.base_url, headers=self.headers).text
        """
        limit_info = self.remaining_limit(response)
        expires = self.when_expire(response)
        xbmcgui.Dialog().ok('Twój transfer', f'Aktualnie posiadasz: [B]{limit_info}[/B] \nWażne do: [B]{expires}[/B]')
        """
        text = parseDOM(response, "div", attrs={"class": "textPremium"})
        if text:
            text = text[0]
        else:
            text = 'Wystąpił jakiś błąd'
        text = text.replace('<br />', '\n')
        text = text.replace('<b>', '[B]').replace('</b>', '[/B]')
        text = re.sub('<[^>]+>', '', text)
        xbmcgui.Dialog().ok('Twój transfer', f'{text}')
        """
        if addon_handle > 0:
            #add_item(f"...", '', False, {'action': 'nothing'}, 'false')
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=True)
            xbmc.sleep(100)
            xbmc.executebuiltin('Action(Back)')
        """ 

    def remaining_limit(self, response=""):
        limit_info = parseDOM(response, "div", attrs={"class": "textPremium"})
        try:
            remaining_limit = str(parseDOM(limit_info, "b")[-1])
        except Exception:
            remaining_limit = 'nieznany'
        remaining_limit = re.sub(r"\s*\w+\s*=\s*([\"']?).*?\1(?=[\s>]|$)\s*", "", remaining_limit)
        remaining_limit = re.sub('<[^>]+>', '', remaining_limit)
        return remaining_limit


    def when_expire(self, response=""):
        expires = parseDOM(response, "div", attrs={"class": "textPremium"})
        expires = parseDOM(expires, "b")
        if len(expires) > 1:
            expires = str(expires[0])
        else:
            expires = "nie dotyczy"
        return expires


    def prepare_filename_to_display(self, filename):
        # Pozwoli zawijać tekst (aby mieścił się w okienku)
        filename = filename[:-4].replace(".", " ").replace("_", " ") + filename[-4:]
        # Wywalenie ostatniego myślnika - zazwyczaj jest po nim nazwa "autora" pliku
        filename = re.sub(r"-(?=\w+( \(\d\))?\.\w{2,4}$)", " ", filename, flags=re.I)
        # przywrócenie niezbędnych kropek i kresek dla niektórych fraz
        filename = self.replace_audio_format_in_filename(filename)
        return filename


    def replace_audio_format_in_filename(self, filename):
        replacements = [
            (r"(?<!\d)([57261]) ([10])\b", r"\1.\2"),  # ilość kanałów, np. 5.1 czy 2.0
            (r"\b([hx]) (26[45])\b", r"\1.\2", re.I),  # h264 x264 x265 h265
            (r"\b(DDP?) (EX)\b", r"\1-\2", re.I),  # np. DD-EX
            (r"\b(DTS) (HD(?!-?(?:TS|cam|TV))|ES|EX|X(?![ .]26))\b", r"\1-\2", re.I),  # DTS
            (r"\b(AAC) (LC)\b", r"\1-\2", re.I),  # AAC-LC
            (r"\b(AC) (3)\b", r"\1-\2", re.I),  # AC-3
            (r"\b(HE) (AAC)\b", r"\1-\2", re.I),  # HE-AAC
            (r"\b(WEB|Blu|DVD|DCP|B[DR]|HD) (DL|Ray|RIP|Rip|Rip|TS)\b", r"\1-\2", re.I),
        ]
        for pattern in replacements:
            if len(pattern) == 3:
                old, new, flags = pattern
                filename = re.sub(old, new, filename, flags=flags)
            else:
                old, new = pattern
                filename = re.sub(old, new, filename)
        return filename

        
    def settings(self):
        # xbmc.executebuiltin('Addon.OpenSettings(' + addon.getAddonInfo('id') + ')')
        addon.openSettings()
        

   