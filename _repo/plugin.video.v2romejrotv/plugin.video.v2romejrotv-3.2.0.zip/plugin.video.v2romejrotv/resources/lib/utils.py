import xbmc
import xbmcgui
import xbmcplugin
import sys
import requests
from urllib.parse import quote_plus
from resources.lib.modules import romejrotv # i inne Twoje źródła

TMDB_API_KEY = 'a07324c669cac4d96789197134ce272b'

def search_and_play_from_tmdb(tmdb_id, media_type):
    if not tmdb_id or not media_type:
        xbmcgui.Dialog().notification("RomejroTV", "Brak danych TMDB", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    # Pobierz dane z TMDB
    tmdb_url = f'https://api.themoviedb.org/3/{media_type}/{tmdb_id}?api_key={TMDB_API_KEY}&language=pl-PL'
    r = requests.get(tmdb_url)
    if r.status_code != 200:
        xbmcgui.Dialog().notification("RomejroTV", "Nie można pobrać danych TMDB", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    data = r.json()
    title = data.get('title') or data.get('name')
    year = data.get('release_date', '')[:4]

    if not title:
        xbmcgui.Dialog().notification("RomejroTV", "Nie znaleziono tytułu", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    # Szukaj po nazwie we wszystkich źródłach
    search_results = []
    for source in [romejrotv]:  # Dodaj inne źródła tutaj
        try:
            flinks, slinks, _ = source.ListSearch(title, page='1')  # lub inne parametry
            search_results.extend(flinks or [])
            search_results.extend(slinks or [])
        except:
            continue

    if not search_results:
        xbmcgui.Dialog().notification("RomejroTV", f"Brak wyników dla: {title}", xbmcgui.NOTIFICATION_INFO, 4000)
        return

    # Spróbuj odtworzyć pierwszy wynik
    item = search_results[0]
    stream_url = item.get('url')
    if stream_url:
        li = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    else:
        xbmcgui.Dialog().notification("RomejroTV", "Nie udało się znaleźć linku", xbmcgui.NOTIFICATION_ERROR, 4000)
