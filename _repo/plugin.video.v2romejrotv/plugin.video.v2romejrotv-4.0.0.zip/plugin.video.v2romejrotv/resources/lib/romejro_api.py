
import os
import json
import time
import uuid
import requests
import xbmcaddon
import xbmcvfs
import xbmc

BASE_URL = 'https://romejrotv.blu24.pl/'
API_URL = BASE_URL + 'api/'


addon = xbmcaddon.Addon('plugin.video.v2romejrotv')


PROFILE = xbmcvfs.translatePath(
    addon.getAddonInfo('profile')
)


if not os.path.exists(PROFILE):
    os.makedirs(PROFILE)


TOKEN_FILE = os.path.join(PROFILE, 'api_tokens.json')


def _load_tokens():
    try:
        with open(TOKEN_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_tokens(data):
    with open(TOKEN_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f)


def get_device_id():

    tokens = _load_tokens()

    if tokens.get('device_id'):
        return tokens['device_id']

    device_id = uuid.uuid4().hex

    tokens['device_id'] = device_id

    _save_tokens(tokens)

    return device_id


def activate(activation_code):

    device_id = get_device_id()

    response = requests.post(
        API_URL + 'auth.php',
        json={
            'device_id': device_id,
            'activation_code': activation_code
        },
        timeout=10
    )

    xbmc.log(
        '[RomejroTV] AUTH HTTP: ' + str(response.status_code),
        xbmc.LOGERROR
    )

    xbmc.log(
        '[RomejroTV] AUTH RESPONSE: ' + response.text[:2000],
        xbmc.LOGERROR
    )

    if response.status_code != 200:
        raise Exception(
            'HTTP ' + str(response.status_code) +
            ': ' + response.text[:500]
        )

    try:
        data = response.json()
    except Exception as e:
        raise Exception(
            'Serwer zwrócił niepoprawny JSON: ' +
            response.text[:500]
        )

    if data.get('status') != 'ok':
        raise Exception(
            data.get('message', 'Błąd aktywacji')
        )

    if not data.get('access_token'):
        raise Exception('Brak access_token')

    if not data.get('refresh_token'):
        raise Exception('Brak refresh_token')

    tokens = _load_tokens()

    tokens['device_id'] = device_id
    tokens['access_token'] = data['access_token']
    tokens['refresh_token'] = data['refresh_token']

    tokens['expires_at'] = int(
        data.get(
            'access_expires',
            int(time.time()) + 900
        )
    )

    _save_tokens(tokens)

    return True


def refresh_access_token():

    tokens = _load_tokens()

    refresh_token = tokens.get('refresh_token')

    if not refresh_token:
        raise Exception('BRAK_REFRESH_TOKEN')

    response = requests.post(
        API_URL + 'refresh.php',
        json={
            'refresh_token': refresh_token
        },
        timeout=10
    )

    if response.status_code == 401:
        raise Exception('REFRESH_EXPIRED')

    response.raise_for_status()

    data = response.json()

    if data.get('status') != 'ok':
        raise Exception(
            data.get(
                'message',
                'Błąd odświeżania tokena'
            )
        )

    if not data.get('access_token'):
        raise Exception('BRAK_NOWEGO_ACCESS_TOKEN')

    tokens['access_token'] = data['access_token']

    tokens['expires_at'] = int(
        data.get(
            'access_expires',
            int(time.time()) + 900
        )
    )

    _save_tokens(tokens)

    return True


def api_get(url):

    tokens = _load_tokens()

    access_token = tokens.get('access_token')

    if not access_token:
        raise Exception('Addon nie został aktywowany')

    expires_at = int(
        tokens.get('expires_at', 0)
    )

    now = int(time.time())

    # Jeśli access token wygasł,
    # automatycznie pobieramy nowy.
    if expires_at <= now:

        refresh_access_token()

        tokens = _load_tokens()

        access_token = tokens.get('access_token')

        if not access_token:
            raise Exception('TOKEN_EXPIRED')


    headers = {
        'Authorization': 'Bearer ' + access_token,
        'User-Agent': 'RomejroTV-Kodi'
    }


    response = requests.get(
        url,
        headers=headers,
        timeout=10
    )


    # Jeżeli serwer odrzuci token,
    # próbujemy odświeżyć go tylko raz.
    if response.status_code == 401:

        refresh_access_token()

        tokens = _load_tokens()

        access_token = tokens.get('access_token')

        if not access_token:
            raise Exception('TOKEN_EXPIRED')


        headers = {
            'Authorization': 'Bearer ' + access_token,
            'User-Agent': 'RomejroTV-Kodi'
        }


        response = requests.get(
            url,
            headers=headers,
            timeout=10
        )


    response.raise_for_status()

    return response.json()

