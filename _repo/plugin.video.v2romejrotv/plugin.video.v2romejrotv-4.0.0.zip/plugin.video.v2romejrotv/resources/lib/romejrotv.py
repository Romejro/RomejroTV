import sys,re,os#, cookielib
import geturl as gethtml
import xbmc, xbmcaddon, xbmcvfs
import urllib.parse
import requests
import json
import xbmcgui
from resources.lib.romejro_api import api_get

addon = xbmcaddon.Addon(id='plugin.video.v2romejrotv')
PATH = addon.getAddonInfo('path')
if sys.version_info >= (3,0,0):
	DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))#.decode('utf-8')
else:
	DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('Latin_1')
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0'
headers2 = {
	
		'Referer':'https://romejrotv.blu24.pl/pokaz.php',
		'user-agent': UA,
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
	}
cuk = gethtml.get_setting('dguardkukzaluknij')
if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus

    import http.cookiejar as cookielib
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    
from requests.compat import urlparse


cj ={}
kuksy2=''.join(['%s=%s;'%(c.name, c.value) for c in cj])
#conn.text_factory = lambda x: x.decode('latin_1')

basurl='https://romejrotv.blu24.pl'


# def ListContent(url, page):
#     html, kuks = gethtml.getRequests4(url, headers=headers2, cookies=cj)
#     npage = []
#     fout = []
#     sout = []

#     try:
#         data = json.loads(html)
#     except Exception:
#         return fout, sout, npage

#     cookie_str = kuks[:-1] if kuks else ''
#     image_suffix = f"|User-Agent={quote(UA)}&Cookie={cookie_str}"

#     # 1. Przetwarzanie filmów
#     for film in data.get('filmy', []):
#         tytul = film.get('tytul', '')
#         href = film.get('url', '')
#         imag = film.get('src', '')
#         if imag:
#             imag += image_suffix

#         kateg = film.get('kategoria', '')
#         opis_raw = film.get('opis', '')
#         plot = f"{kateg} {opis_raw}".strip()

#         fout.append({
#             'title': tytul,
#             'url': href,
#             'image': imag,
#             'plot': plot,
#             'year': '',
#             'code': '',
#             'genre': kateg,
#             'duration': '',
#             'mode2': 'dudaplayer'
#         })

#     # 2. Przetwarzanie seriali
#     for serial in data.get('seriale', []):
#         tytul = serial.get('tytul', '')
#         href = serial.get('url', '')
#         imag = serial.get('okladka', '')
#         if imag:
#             imag += image_suffix

#         kateg = serial.get('kategoria', '')
#         opis_raw = serial.get('opis', '')
#         plot = f"{kateg} {opis_raw}".strip()

#         sout.append({
#             'title': tytul,
#             'url': href,
#             'image': imag,
#             'plot': plot,
#             'year': '',
#             'code': '',
#             'genre': kateg,
#             'duration': '',
#             'mode2': 'dudaplayer'
#         })

#     return fout, sout, npage

def getSerial(url):
    episodes = []
    
    # 1. Naprawa adresu URL (dodanie domeny i konwersja do API serial.php)
    if not url.startswith('http'):
        url = basurl + ('/' if not url.startswith('/') else '') + url

    # Wyciąganie ID serialu (obsługuje linki typu ?id=79 oraz /serial-online/79/...)
    import re
    match_id = re.search(r'(?:id=|\/)(\d+)', url)
    if match_id:
        serial_id = match_id.group(1)
        url = f"{basurl}/serialjson.php?id={serial_id}"

    # 2. Pobieranie JSON z API
    try:
        #res = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)
        
# Dekodujemy bezpośrednio surowe bajty (res.content) na ciąg UTF-8
        
        
        response = api_get(url)
        if response.get('status') == 'success':
            tytul_serialu = response.get('tytul', '')
            img = response.get('okladka', '')
            
            for sezon_data in response.get('sezony', []):
                nr_sezonu = sezon_data.get('sezon', 0)
                
                for ep in sezon_data.get('odcinki', []):
                    tyt2 = ep.get('tytul_odcinka', '')
                    href = ep.get('link', '')
                    opis = ep.get('opis', '')
                    idlink = str(ep.get('id', ''))
                    
                    obejrzany = f"[B][COLOR green] {tyt2} [/COLOR][/B]"
                    nobejrzany = f"[B][COLOR white] {tyt2} [/COLOR][/B] - {tytul_serialu}"
                    
                    episodes.append({
                        'titok': obejrzany,
                        'titnot': nobejrzany,
                        'url': href,
                        'image': img,
                        'plot': opis,
                        'season': int(nr_sezonu),
                        'episode': 0,
                        'idlin': idlink
                    })
        else:
            msg = response.get('message', 'Błąd API')
            xbmcgui.Dialog().notification('Błąd API', msg, xbmcgui.NOTIFICATION_ERROR, 4000)

    except Exception as e:
        xbmc.log(f"[ROMEJROTV] Błąd getSerial ({url}): {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Błąd połaczenia', str(e), xbmcgui.NOTIFICATION_ERROR, 4000)

    return splitToSeasons(episodes)


def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	

def RecentlyView(url, page):
    npage = []
    results = []

    try:
        data = api_get(url)
        
        for item in data.get('elementy', []):
            typ = item.get('type', 'film')
            tytul = item.get('tytul', '')
            href = item.get('url', '')
            imag = item.get('src') or item.get('okladka', '')
            kateg = item.get('kategoria', '')
            opis = item.get('opis', '')
            plot = f"{kateg} {opis}".strip()

            results.append({
                'title': tytul,
                'url': href,
                'image': imag,
                'plot': plot,
                'year': '',
                'code': '',
                'genre': kateg,
                'duration': '',
                'mode2': 'dudaplayer',
                'type': typ
            })
    except Exception as e:
        xbmc.log(f"[ROMEJROTV] Błąd RecentlyView: {e}", xbmc.LOGERROR)

    return results, npage



def ListContentSearch(url, page):
    html, kuks = gethtml.getRequests4(url, headers=headers2, cookies=cj)
    
    npage = []
    fout = []
    sout = []

    try:
        data = api_get(url)
    except Exception as e:
        xbmc.log(
            f'[RomejroTV] Błąd API search: {str(e)}',
            xbmc.LOGERROR
        )
        return fout, sout, npage

    cookie_str = ''
    image_suffix = f"|User-Agent={quote(UA)}&Cookie={cookie_str}"

    for film in data.get('filmy', []):
        tytul = film.get('tytul', '')
        href = film.get('url', '')
        imag = film.get('src', '')
        if imag:
            imag += image_suffix

        kateg = film.get('kategoria', '')
        opis_raw = film.get('opis', '')
        plot = f"{kateg} {opis_raw}".strip()

        fout.append({
            'title': tytul,
            'url': href,
            'image': imag,
            'plot': plot,
            'year': '',
            'code': '',
            'genre': kateg,
            'duration': '',
            'mode2': 'dudaplayer'
        })

    for serial in data.get('seriale', []):
        tytul = serial.get('tytul', '')
        href = serial.get('url', '')
        imag = serial.get('okladka', '')
        if imag:
            imag += image_suffix

        kateg = serial.get('kategoria', '')
        opis_raw = serial.get('opis', '')
        plot = f"{kateg} {opis_raw}".strip()

        sout.append({
            'title': tytul,
            'url': href,
            'image': imag,
            'plot': plot,
            'year': '',
            'code': '',
            'genre': kateg,
            'duration': '',
            'mode2': 'dudaplayer'
        })

    return fout, sout, npage
# def getVideo(url,title):

# 	out=[]
# 	html,kuks = gethtml.getRequests4(url,headers=headers2, cookies=cj)
# 	stream_url=''
# 	kopiujlink = ""
# 	pobid = ''
# 	result = parseDOM(html,'tbody')
# 	if result:
# 		result=result[0]
        
# 		pobids = parseDOM(result, 'td', attrs={'class': 'pobid'})
# 		
# 		if pobids:
# 		    pobid = pobids[0]  # tylko pierwszy
        
# 		videos = parseDOM(result,'tr')
# 		for vid in videos:
# 			wersje = parseDOM(vid, 'td', attrs={'class': 'wersja'})
# 			wersja = ' |'+wersje[0].strip()+'|' if wersje and wersje[0].strip() else ' '
            
# 			hosthref = re.findall(r'href="([^"]+)"', vid)
            
# 			for href in hosthref:
# 			    host = urlparse(href).netloc or "Brak hosta"
# 			    host += f' {wersja}'
# 			    out.append({'href': href, 'host': host})

                
# 		out.append({'href': 'tb7_search', 'host': 'Szukaj w TB7.pl'})
# 		if out:
# 			if len(out) > 1:
# 				u = [ x.get('href') for x in  out]
# 				h = [ x.get('host') for x in  out]
# 				sel = gethtml.selectDialog(title, h)
# 				href = out[sel].get('href') if sel>-1 else quit()
# 			else:
# 				href = out[0].get('href')
# 			if href:
# 				if 'token' in href or '.mkv' in href or 'tb7_search' in href:
# 				    kopiujlink = href
# 				else:
# 				    headers = {

# 					'user-agent': UA,
# 					'accept': '*/*',
# 					'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
# 					'x-requested-with': 'XMLHttpRequest',
# 					'referer': url,
# 					'cookie':cuk,
# 					'te': 'trailers',}
# 				    stream_url,kuks =gethtml.getRequestsRedirUrl(href,headers=headers)
# 				    kopiujlink = href
# 			else:
# 				return stream_url,'quit',kopiujlink, pobid
# 	return stream_url,True,kopiujlink,pobid


def getVideo(url, title):
    out = []
    stream_url = ''
    kopiujlink = ''
    pobid = ''

    # 1. Pobranie danych z nowego API JSON
    try:
        #response = requests.get(url, headers=headers2, timeout=10).json()
        response = api_get(url)
        if response.get('status') == 'success':
            pobid = str(response.get('id', ''))
            for zrodlo in response.get('zrodla', []):
                wersja = zrodlo.get('wersja', '').strip()
                href = zrodlo.get('url', '').strip()
                if href:
                    full_href = f"{wersja}|{href}" if wersja else href
                    host = urlparse(href).netloc or "Brak hosta"
                    out.append({'href': full_href, 'host': host})
    except Exception as e:
        xbmc.log(f"[ROMEJROTV] Błąd pobierania JSON z {url}: {e}", xbmc.LOGERROR)
        return '', 'quit', '', ''

    # 2. Dodanie alternatywnej opcji TB7 na końcu listy
    out.append({'href': 'tb7_search', 'host': 'Szukaj w TB7.pl'})

    autoplay = xbmcaddon.Addon().getSetting("autoplay")

    # 3. Obsługa wyboru źródła (Autoplay OFF / ON)
    if out:
        href = None
        if autoplay == "false":
            if len(out) > 1:
                h = []
                for x in out:
                    wersja = ''
                    if '|' in x['href']:
                        wersja, _ = x['href'].split('|', 1)
                    if wersja:
                        h.append(f"{x['host']} | {wersja}")
                    else:
                        h.append(x['host'])
                sel = gethtml.selectDialog(title, h)
                if sel > -1:
                    href = out[sel].get('href')
                    if '|' in href:
                        _, href = href.split('|', 1)
                else:
                    return '', 'quit', '', pobid
            else:
                href = out[0].get('href')
                if '|' in href:
                    _, href = href.split('|', 1)
        else:
            preferowane_hosty = ['voe.sx', 'streamtape.com', 'vid-guard.com', 'dood.yt', 'doodstream.com', 'vidoza.net']
            preferowane_wersje = ['Lektor', 'Dubbing', 'Dubbing Kino', 'Napisy', 'Napisy Trans', 'ENG']

            def get_version_host_and_url(item):
                href_val = item['href']
                wersja = ''
                url_val = href_val
            
                if '|' in href_val:
                    wersja, url_val = href_val.split('|', 1)
                host = urlparse(url_val).netloc.lower()
                return wersja.strip().upper(), host, url_val.strip()

            posortowane_linki = []
            
            for wersja_pref in preferowane_wersje:
                for host_pref in preferowane_hosty:
                    for item in out:
                        wersja, host, url_val = get_version_host_and_url(item)
                        if wersja_pref.lower() == wersja.lower() and host_pref in host and url_val != 'tb7_search':
                            if item not in posortowane_linki:
                                item['url'] = url_val
                                posortowane_linki.append(item)
                                
            for host_pref in preferowane_hosty:
                for item in out:
                    wersja, host, url_val = get_version_host_and_url(item)
                    if host_pref in host and url_val != 'tb7_search' and item not in posortowane_linki:
                        item['url'] = url_val
                        posortowane_linki.append(item)

            for item in out:
                wersja, host, url_val = get_version_host_and_url(item)
                if item not in posortowane_linki and url_val != 'tb7_search':
                    item['url'] = url_val
                    posortowane_linki.append(item)

            for item in posortowane_linki:
                url_val = item.get('url', item['href'])
                href = url_val
                xbmcgui.Dialog().notification('RomejroTV', href, xbmcgui.NOTIFICATION_INFO, 8000)
                break

        if not href:
            return '', 'quit', '', pobid

        # 4. Resolver / wyciąganie finalnego linku
        if href:
            if 'token' in href or '.mkv' in href or '.odycdn.com' in href or 'tb7_search' in href:
                kopiujlink = href
            else:
                headers = {
                    'user-agent': UA,
                    'accept': '*/*',
                    'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
                    'x-requested-with': 'XMLHttpRequest',
                    'referer': url,
                    'cookie': cuk,
                    'te': 'trailers',
                }
                try:
                    stream_url, kuks = gethtml.getRequestsRedirUrl(href, headers=headers)
                except requests.exceptions.RequestException as e:
                    xbmc.log(f"[ROMEJROTV] Błąd pobierania przekierowania: {e}", xbmc.LOGERROR)
                    return '', 'quit', kopiujlink, pobid
                kopiujlink = href
    else:
        return stream_url, 'quit', kopiujlink, pobid

    return stream_url, True, kopiujlink, pobid



def szukcd(d, page=1):
    fout = []
    sout = []
    npage = []

    if not d or not str(d).strip():
        return fout, sout, npage

    encoded_phrase = urllib.parse.quote_plus(str(d).strip())
    url = f"{basurl}/searchjson.php?phrase={encoded_phrase}"
    if page and int(page) > 1:
        url += f"&page={str(page)}"

    try:
        #response = requests.get(url, headers={'User-Agent': UA}, timeout=10, verify=False)
        data = api_get(url)

        if data:

            for film in data.get('filmy', []):
                fout.append({
                    'title': film.get('tytul', ''),
                    'url': film.get('url', ''),
                    'image': film.get('src', ''),
                    'plot': f"{film.get('kategoria', '')} {film.get('opis', '')}".strip(),
                    'genre': film.get('kategoria', ''),
                    'mode2': 'romejrotv'
                })

            for serial in data.get('seriale', []):
                sout.append({
                    'title': serial.get('tytul', ''),
                    'url': serial.get('url', ''),
                    'image': serial.get('okladka', ''),
                    'plot': f"{serial.get('kategoria', '')} {serial.get('opis', '')}".strip(),
                    'genre': serial.get('kategoria', ''),
                    'mode2': 'romejrotv'
                })
    except Exception as e:
        xbmc.log(f'[RomejroTV] Błąd wyszukiwania szukcd dla "{d}": {e}', xbmc.LOGERROR)

    return fout, sout, npage

	
def ListSearch(url, page):    
    d = ''
    # Zabezpieczenie przed wartością None
    if url and isinstance(url, str) and 'phrase=' in url:
        try:
            d = urllib.parse.unquote(url.split('phrase=')[1].split('&')[0])
        except Exception:
            d = ''
            
    # Jeśli brak frazy w URL (pierwsze wyszukanie), pytamy użytkownika
    if not d:
        d = gethtml.inputDialog(u'Szukaj...')
        
    fout = []
    sout = []
    npage = []

    if d:
        fout, sout, npage = szukcd(d, page)

    return fout, sout, npage


