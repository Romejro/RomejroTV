import sys,os

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
import six
import sqlite3
import urllib.parse
from six.moves import urllib_parse
from xbmcvfs import translatePath
from urllib.parse import unquote
from html import unescape
import requests, re
from resources.lib import control
from resources.lib.cmf3 import parseDOM
from resources.lib.cmf3 import replaceHTMLCodes
from urllib.parse import parse_qs, quote, urlencode, quote_plus

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict( urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.v2romejrotv')
xbmc.log(f"addon_handle: {addon_handle}", xbmc.LOGINFO)
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LASTPLAYED, label2Mask = "%R, %P, %Y")

autoplay = xbmcaddon.Addon().getSetting("autoplay")

PATH = addon.getAddonInfo('path')



if sys.version_info >= (3,0,0):
	DATAPATH		= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
else:
	DATAPATH		= xbmc.translatePath(addon.getAddonInfo('profile'))

if isinstance(DATAPATH, bytes):
	DATAPATH = DATAPATH.decode('Latin_1')
if isinstance(PATH, bytes):
	PATH = PATH.decode('Latin_1')
	
addon_id = 'plugin.video.v2romejrotv'
user_data_path = translatePath(f'special://profile/addon_data/{addon_id}/')

db_file = os.path.join(user_data_path, 'database.db')
txt_file = os.path.join(user_data_path, 'watch_last.txt')


# === INICJALIZACJA ===
def init_storage():
    if not os.path.exists(user_data_path):
        os.makedirs(user_data_path)

    # Inicjalizacja pliku tekstowego
    if not os.path.exists(txt_file):
        with open(txt_file, 'w', encoding='latin-1') as f:
            f.write('')  # pusty plik

    # Inicjalizacja bazy SQLite
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Obejrzane (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tytul TEXT NOT NULL,
            idodcinka TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()
if not os.path.exists(db_file):
    print('Brak Pliku DB')
else:
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    
RESOURCES	   = PATH+'/RESOURCES/'
napisy = os.path.join(DATAPATH,'napisy')
DOMENA = 'https://romejrotv.blu24.pl/'


FANART=PATH+'/fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)
season = params.get('season', None)
episode = params.get('episode', None)
tvshowtitle = params.get('tvshowtitle', None)
tmdbid = params.get('tmdbid', None)
mediatype = params.get('mediatype', None)

try:
    opisb = eval(params.get('opisb', None))
except:
    opisb = params.get('opisb', None)
UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'

def build_url(query):
	return base_url + '?' + urllib_parse.urlencode(query)

def add_item(
    url, name, image, mode,
    folder=False, IsPlayable=False, fanart=None,
    infoLabels=None, movie=True, itemcount=1, page=1,
    moviescount=0, playcount=0,
    season=None, episode=None, tvshowtitle=None,
    tmdbid=None, mediatype=None
):
    list_item = xbmcgui.ListItem(name)

    if IsPlayable:
        list_item.setProperty("IsPlayable", 'true')

    if not infoLabels:
        infoLabels = {}

    infoLabels.update({
        'title': name,
        'plot': infoLabels.get('plot', name),
        'playcount': playcount,
        'mediatype': mediatype if mediatype else ('movie' if movie else 'episode'),
    })

    if not movie:
        # Dodaj dane tylko dla odcinków
        if season: infoLabels['season'] = int(season)
        if episode: infoLabels['episode'] = int(episode)
        if tvshowtitle: infoLabels['tvshowtitle'] = tvshowtitle

    list_item.setInfo(type="video", infoLabels=infoLabels)

    # Ustaw identyfikator TMDb (do Trakt i biblioteki)
    if tmdbid:
        list_item.setUniqueIDs({'tmdb': str(tmdbid)})

    list_item.setArt({
        'thumb': image,
        'poster': image,
        'banner': image,
        'fanart': fanart or image
    })

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url({
            'mode': mode,
            'url': url,
            'page': page,
            'moviescount': moviescount,
            'movie': movie,
            'name': name,
            'image': image,
            'season': season,
            'episode': episode,
            'tvshowtitle': tvshowtitle,
            'tmdbid': tmdbid,
            'mediatype': infoLabels['mediatype'],
            'opisb': str(infoLabels)
        }),
        listitem=list_item,
        isFolder=folder
    )


def nontitle(rodzaj,tytul):
    import requests
    import datetime
    czas = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # split_di = di.split('?id=')
    # if len(split_di) > 1:
    #     idpob = split_di[1]
    # else:
    #     idpob = ''  # lub jakaś inna wartość domyślna / logowanie błędu
    #     xbmc.log(f'[ROMEJROTV] Brak "?id=" w URL: {di}', xbmc.LOGERROR)

    tytul_czysty = re.sub(r'\[/?(B|COLOR( white| green)?)\]', '', tytul)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = {
        'rodzaj': rodzaj,
        'czas': czas,
        'tytul': tytul_czysty.strip()
    }
    response = requests.post(DOMENA+'notwork.php?dodaj=nontitle', data=data, headers=headers)

def nwlink(di,rodzaj,link,tytul):
    import requests
    import datetime
    czas = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # split_di = di.split('?id=')
    # if len(split_di) > 1:
    #     idpob = split_di[1]
    # else:
    #     idpob = ''  # lub jakaś inna wartość domyślna / logowanie błędu
    #     xbmc.log(f'[ROMEJROTV] Brak "?id=" w URL: {di}', xbmc.LOGERROR)

    tytul_czysty = re.sub(r'\[/?(B|COLOR( white| green)?)\]', '', tytul)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = {
        'idsf': di,
        'rodzaj': rodzaj,
        'link': link,
        'czas': czas,
        'tytul': tytul_czysty.strip()
    }
    response = requests.post(DOMENA+'notwork.php?dodaj=nwlink', data=data, headers=headers)
    if autoplay == "true":
        wiad = 'Spróbuj jeszcze raz'    
    else:
        wiad = 'Spróbuj inny'
    xbmcgui.Dialog().notification('[B]Link nie działa[/B]', wiad ,xbmcgui.NOTIFICATION_INFO, 6000,False)


def obejrzany_dodaj(nazwaodc,idodc):
    # Otwieramy plik w trybie dopisywania
    # with open(PATH+'obejrzane.txt', 'a') as plik:
    #     plik.write(nazwaodc + '\n')  # Dodajemy rekord i nową linię
    cursor.execute('INSERT INTO Obejrzane (tytul, idodcinka) VALUES (?, ?)', (nazwaodc,idodc,))
    conn.commit()  # Zatwierdzenie zmian
def recently_view(idmovie):
    # Otwieramy plik w trybie dopisywania
    
    with open(txt_file, 'r+', encoding='latin-1') as plik:
        # Odczytaj istniejącą zawartość
        zawartosc = plik.read().strip()  # Odczytaj zawartość i usuń białe znaki
        istniejące_pozycje = zawartosc.split(',') if zawartosc else []
        
        if 'pokazs' in idmovie:
            nowe_pozycje = 's-'+idmovie
        else:
            nowe_pozycje = idmovie
        # Dodaj nowe pozycje na początku
        wszystkie_pozycje = nowe_pozycje + istniejące_pozycje
        
        # Zachowaj maksymalnie 10 pozycji
        wszystkie_pozycje = wszystkie_pozycje[:50]
        
        # Zapisz zaktualizowaną listę do pliku
        plik.seek(0)  # Przesuń wskaźnik na początek pliku
        plik.write(','.join(wszystkie_pozycje) + '\n')
        plik.truncate()  # Utnij plik w przypadku, gdy nowa zawartość jest krótsza
        

def szukaj_tb7(title, year="", season=None, episode=None):
    try:
        session = requests.Session()
        base_url = "https://tb7.pl/"
        login_url = base_url + "login"
        search_url = base_url + "mojekonto/szukaj"

        # Pobierz login i hasło z ustawień dodatku
        username = control.setting("tb7.username")
        password = control.setting("tb7.password")

        if not username or not password:
            xbmcgui.Dialog().notification("TB7", "Brakuje danych logowania w ustawieniach", xbmcgui.NOTIFICATION_ERROR)
            return "", ""

        # Logowanie
        r = session.post(login_url, data={"login": username, "password": password}, verify=False)
        if username not in r.text:
            xbmcgui.Dialog().notification("TB7", "Logowanie nieudane", xbmcgui.NOTIFICATION_ERROR)
            return "", ""

        # Przygotowanie frazy
        query = title
        if season and episode:
            query += f" S{int(season):02d}E{int(episode):02d}"
        elif year:
            query += f" {year}"

        post_data = {"search": query, "type": "1"}
        r = session.post(search_url, data=post_data, verify=False)
        html = r.text.replace("\n", "")

        # Parsowanie wyników
        rows = re.findall(r'<tr>(.*?)</tr>', html)
        sources = []
        for row in rows:
            href_match = re.search(r'<input[^>]*value="([^"]+)"', row)
            name_match = re.search(r'<label[^>]*>(.*?)</label>', row)
            size_match = re.search(r'<td[^>]*>([\d.,]+ ?[MG]B)</td>', row)

            if href_match and name_match:
                url = href_match.group(1)
                name = unescape(unquote(name_match.group(1)))
                size = size_match.group(1) if size_match else "brak"

                sources.append({
                    "url": url,
                    "label": f"{name} | {size}"
                })

        if not sources:
            xbmcgui.Dialog().notification("TB7", "Brak wyników", xbmcgui.NOTIFICATION_INFO)
            return "", ""

        # Wybór przez użytkownika
        sel = xbmcgui.Dialog().select("Wybierz źródło TB7", [s["label"] for s in sources])
        if sel == -1:
            return "", ""

        selected = sources[sel]

        # Pobranie finalnego linku
        sciagaj1 = base_url + "mojekonto/sciagaj"
        session.post(sciagaj1, data={"step": "1", "content": selected["url"]})
        r2 = session.post(sciagaj1, data={"0": "on", "step": "2"})
        match = re.search(r'<a[^>]+href="([^"]+)"', r2.text)
        final_url = match.group(1) if match else None

        if not final_url:
            xbmcgui.Dialog().notification("TB7", "Nie udało się pobrać linku", xbmcgui.NOTIFICATION_ERROR)
            return "", ""

        return final_url, selected["url"]

    except Exception as e:
        xbmcgui.Dialog().notification("TB7", f"Błąd: {e}", xbmcgui.NOTIFICATION_ERROR)
        return "", ""

    
    
def getEpisodes(seasons, mode2):
    import ast
    import urllib.parse

    # Bezpieczniejsze dekodowanie i parsowanie, zamiast eval spróbuj ast.literal_eval
    try:
        episodes = ast.literal_eval(urllib.parse.unquote_plus(seasons))
    except Exception as e:
        xbmc.log(f"Error parsing episodes: {e}", level=xbmc.LOGERROR)
        episodes = []

    if not isinstance(episodes, (list, tuple)):
        xbmc.log(f"Expected list or tuple for episodes, got {type(episodes)}", level=xbmc.LOGERROR)
        episodes = []

    items = len(episodes)
    xbmc.executebuiltin("Container.Refresh")

    for f in episodes:
        ses = f.get('season')
        epp = f.get('episode')
        idlinku = f.get('idlin')

        cursor.execute('SELECT EXISTS(SELECT * FROM obejrzane WHERE idodcinka = ?)', (idlinku,))
        exists = cursor.fetchone()[0]

        if exists:
            tytul = f.get('titok')
            if isinstance(tytul, str):
                tytul = tytul.encode('Latin_1', errors='ignore')
            playcount = 1
        else:
            tytul = f.get('titnot')
            if isinstance(tytul, str):
                tytul = tytul.encode('Latin_1', errors='ignore')
            playcount = 0

        add_item(name=tytul, url=f.get('url'), mode='getVid:%s' % mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot': f.get('plot')}, itemcount=items, playcount=playcount)

    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.endOfDirectory(addon_handle)

def PlayVid(stream_url,adaptive=False):

	
	play_item = xbmcgui.ListItem(path=stream_url)
	try:
# 	    play_item.setProperty('ResumeTime', '120')
# 	    play_item.setProperty('TotalTime', '3600')
# 	    play_item.setProperty('StartOffset', '120')
	    
	    info_tag = play_item.getVideoInfoTag()
	    if mediatype == 'episode':
	        info_tag.setTitle(tvshowtitle)
	    else:
	        info_tag.setTitle(name)# ← powinien być tytuł odcinka/filmu
	    info_tag.setPlot(opisb.get('plot') if isinstance(opisb, dict) else '')
	    if season:
	        info_tag.setSeason(int(season))
	    if episode:
	        info_tag.setEpisode(int(episode))
	    if tvshowtitle:
	        info_tag.setTvShowTitle(name)
	    if mediatype:
	        info_tag.setMediaType(mediatype)
	    if tmdbid:
	        info_tag.setUniqueIDs({'tmdb': tmdbid}, 'tmdb')
	except:
		pass
	play_item.setProperty("IsPlayable", "true")
# 	play_item.setProperty('upnext', 'true')
    
    
# 	try:
# 	    season_int = int(season) if season else 1
# 	    episode_int = int(episode) if episode else 1
# 	except ValueError:
# 	    season_int = 1
# 	    episode_int = 1

# 	next_episode = episode_int + 1

# 	next_url = f'plugin://plugin.video.v2romejrotv/?mode=create_player&type=tv&tmdb_id={tmdbid}&season={season_int}&episode={next_episode}'
# 	play_item.setProperty('next_file', next_url)
# 	play_item.setProperty('tmdb_id', str(tmdbid))
# 	play_item.setProperty('season', str(season_int))
# 	play_item.setProperty('episode', str(episode_int))
# 	play_item.setProperty('tvshowtitle', tvshowtitle or name)
# 	play_item.setInfo('video', {
#     'title': name,
#     'plot': opisb.get('plot') if isinstance(opisb, dict) else '',
#     'season': int(season) if season and season.isdigit() else None,
#     'episode': int(episode) if episode.isdigit() else None,
#     'tvshowtitle': tvshowtitle if tvshowtitle else '',
#     'mediatype': mediatype if mediatype else 'movie',
#         })

	if adaptive:
		if six.PY2:
			play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
		else:
			if stream_url.endswith('.mkv'):
                # Bez inputstream.adaptive – zwykły plik wideo
			    play_item.setMimeType('video/x-matroska')
			 
			    
			    
			elif 'm3u8' in stream_url or 'hls' in stream_url:
                # Odtwarzanie HLS
# 			    play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
# 			    play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
# 			    play_item.setMimeType('application/vnd.apple.mpegurl')
# 			    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')

			    play_item.setPath(stream_url)
			    play_item.setMimeType('application/vnd.apple.mpegurl')
			    play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')  # <-- poprawka tutaj
# 			    play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
# 			    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')

			    
			else:
                # Domyślnie – zwykły plik bez adaptive
			    play_item.setProperty('IsPlayable', 'true')
	if addon_handle >= 0:
	    xbmcplugin.setResolvedUrl(addon_handle, True, play_item)
	else:
	    xbmc.Player().play(stream_url, play_item)
	xbmc.log(f"RomejroTV | Resolved URL: {addon_handle} {stream_url}", xbmc.LOGINFO)
			    
# 			if 'token' in stream_url or 'mkv' in stream_url:
# 			    xbmc.Player().play(stream_url, play_item)
# 			else:
# 			    play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
# 			    play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
# 			    play_item.setMimeType('application/vnd.apple.mpegurl')
# 			    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
# 			    player = xbmc.Player()
# 			    player.play(stream_url, play_item)
		#play_item.setContentLookup(False)
	#else:
	#		#play_item = xbmcgui.ListItem(path=stream_url,label=tytul)
	#		#play_item.setInfo(type="Video", infoLabels={"title": tytul,'plot':tytul})
	#		#
	#		#if '.mp4' in stream_url:
	#	play_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
	#	play_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp4')
	#	play_item.setContentLookup(False)
	#	play_item.setMimeType('video/mp4')
	#	play_item.setProperty('mimetype', 'video/mp4')
	#	play_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
	#	play_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp4')
	#	play_item.setContentLookup(False)
  #	# xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
  
  
def import_mod(s):
	mod = {}
	if   s == 'romejrotv': import romejrotv	 as mod
	
	return mod
	
def home():

	add_item(DOMENA+'kodi.php', '[B][COLOR red]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:romejrotv", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item(DOMENA+'series/index/', '[B][COLOR red]Seriale[/COLOR][/B]', 'DefaultMovies.png', "ListContent:romejrotv", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item('', '[B][COLOR red]Ustawienia[/COLOR][/B]', 'DefaultAddonsSettings.png', "Ustawienia", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item('', '[B][COLOR red]Kategorie[/COLOR][/B]', 'DefaultMovies.png', "Kategorie", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item('', '[B][COLOR red]Ostatnio Oglądane[/COLOR][/B]', 'DefaultMovies.png', "recentlyview", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item('', '[B][COLOR red]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:romejrotv", folder=True,fanart=RESOURCES+'fanart.jpg')


def router(paramstring):
    
    params = dict( urllib_parse.parse_qsl(paramstring))
    if params:
        typv='videos'
        mode = params.get('mode', '')
        if 'Ustawienia' in mode:
            add_item('', '[B][COLOR red]Resetuj obejrzane odcinki[/COLOR][/B]', 'DefaultAddonsSettings.png', "emptywatch", folder=True,fanart=RESOURCES+'fanart.jpg')
            xbmcplugin.setContent(addon_handle, typv)
            xbmcplugin.endOfDirectory(addon_handle)
        elif 'emptywatch' in mode:
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = cursor.fetchall()

            # Opróżnij każdą tabelę
            for table in tables:
                table_name = table[0]
                cursor.execute(f"DELETE FROM {table_name};")
            
            conn.commit()
            xbmcgui.Dialog().notification('[B]Sukces![/B]', 'Wyczyszczono wszystkie obejrzane odcinki',xbmcgui.NOTIFICATION_INFO, 6000,False)
        elif 'Kategorie' in mode:
            add_item('', '[B][COLOR red]Akcja[/COLOR][/B]', DOMENA+'kat/akcja.jpg', "kate:akcja", folder=True,fanart=DOMENA+'fanart.jpg')
            add_item('', '[B][COLOR red]Sensacyjny[/COLOR][/B]', DOMENA+'kat/sensacyjny.jpg', "kate:sensacyjny", folder=True,fanart=DOMENA+'fanart.jpg')
            add_item('', '[B][COLOR red]Obyczajowy[/COLOR][/B]', DOMENA+'kat/obyczajowy.jpg', "kate:obyczajowy", folder=True,fanart=DOMENA+'fanart.jpg')
            add_item('', '[B][COLOR red]Komedia[/COLOR][/B]', DOMENA+'kat/komedia.jpg', "kate:komedia", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Dramat[/COLOR][/B]', DOMENA+'kat/dramat.jpg', "kate:dramat", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Animacja[/COLOR][/B]', DOMENA+'kat/animacja.jpg', "kate:animacja", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Przygodowy[/COLOR][/B]', DOMENA+'kat/przygodowy.jpg', "kate:przygodowy", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Sci-Fi[/COLOR][/B]', DOMENA+'kat/scifi.jpg', "kate:sci-fi", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Familijny[/COLOR][/B]', DOMENA+'kat/familijny.jpg', "kate:familijny", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Horror[/COLOR][/B]', DOMENA+'kat/horror.jpg', "kate:horror", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Thirller[/COLOR][/B]', DOMENA+'kat/thirller.jpg', "kate:thirller", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Dokumentalny[/COLOR][/B]', DOMENA+'kat/dokumentalny.jpg', "kate:dokumentalny", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Dla Dzieci[/COLOR][/B]', DOMENA+'kat/dladzieci.jpg', "kate:dla dzieci", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Komedia Romantyczna[/COLOR][/B]', DOMENA+'kat/komediarom.jpg', "kate:komedia rom", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Romans[/COLOR][/B]', DOMENA+'kat/romans.jpg', "kate:romans", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            
            xbmcplugin.setContent(addon_handle, typv)
            xbmcplugin.endOfDirectory(addon_handle)
        elif 'kate' in mode:
            kateg = mode.split(':')[1]
            mod = import_mod('romejrotv')
            linked = DOMENA+'search.php?phrase='+kateg
            flinks,slinks,pagin = mod.ListContentSearch(linked,page)
        
            if flinks or slinks:
                items1 = len(flinks)
                items2 = len(slinks)
                mud = 'getSimpleSeasons:romejrotv'
                
                if slinks:
                    for f in slinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='tvshows'		
                    xbmcplugin.setContent(addon_handle, typv)	
                    #xbmcplugin.setContent(addon_handle, 'tvshows')	
                if flinks:
                    for f in flinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode='getVid:romejrotv', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='movies'		
                    xbmcplugin.setContent(addon_handle, typv)	
        
                                
                xbmcplugin.endOfDirectory(addon_handle)
            elif not flinks and not slinks:
                return
            else:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
        elif 'recentlyview' in mode:
            filename = txt_file
            if os.path.getsize(filename) == 0:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
            else:
                # Krok 2: Odczytaj zawartość
                with open(filename, 'r', encoding='latin-1') as file:
                    content = file.read()  # lub file.readlines() jeśli wolisz
                
                # Krok 3: Rozbij tekst do tablicy po przecinku
                data_array = content.split(',')
                
                # Usunięcie zbędnych spacji z każdego elementu
                data_array = [item.strip() for item in data_array]
                film = [item if item != '' else '0' for item in data_array]
                link = ','.join(film)
                mod = import_mod('romejrotv')
                linked = DOMENA+'recently.php?pokaz='+link
                results,npage = mod.RecentlyView(linked,page)
                
                for f in results:
                    typ = f.get('type')
                    if typ == 'serial':
                        mode = 'getSimpleSeasons:romejrotv'
                        folder = True
                    else:
                        mode = 'getVid:romejrotv'
                        folder = False
                
                    add_item(
                        name=f.get('title'),
                        url=f.get('url'),
                        mode=mode,
                        image=f.get('image'),
                        folder=folder,
                        IsPlayable=False,
                        infoLabels={
                            'plot': f.get('plot'),
                            'year': f.get('year'),
                            'genre': f.get('genre'),
                            'code': f.get('code')
                        },
                        fanart=f.get('image')
                    )
                
                if addon.getSetting('auto-view') == 'true':
                    xbmcplugin.setContent(addon_handle, 'videos')
                
                xbmcplugin.endOfDirectory(addon_handle)


                
                # if flinks or slinks:
                #     items1 = len(flinks)
                #     items2 = len(slinks)
                #     mud = 'getSimpleSeasons:romejrotv'
                    
                #     if slinks:
                #         for f in slinks:
                            
                #             add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2, fanart=f.get('image'))
                #         if addon.getSetting('auto-view') == 'true':
                #             typv='tvshows'		
                #         xbmcplugin.setContent(addon_handle, typv)	
                #         #xbmcplugin.setContent(addon_handle, 'tvshows')	
                #     if flinks:
                #         for f in flinks:
                            
                #             add_item(name=f.get('title'), url=f.get('url'), mode='getVid:romejrotv', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1, fanart=f.get('image'))
                #         if addon.getSetting('auto-view') == 'true':
                #             typv='movies'		
                #         xbmcplugin.setContent(addon_handle, typv)	
                
                    		
                        
                #     xbmcplugin.endOfDirectory(addon_handle)
                # elif not flinks and not slinks:
                #     return
                # else:
                #     xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
        
        elif 'SimplelistSearch' in mode:
            mode2 = mode.split(':')[1]
            mod = import_mod(mode2)
            
            flinks,slinks,pagin = mod.ListSearch(exlink,page)
            
            if flinks or slinks:
                items1 = len(flinks)
                items2 = len(slinks)
                mud = 'getSimpleSeasons:%s'%mode2
                
                if slinks:
                    for f in slinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='tvshows'		
                    xbmcplugin.setContent(addon_handle, typv)	
                    #xbmcplugin.setContent(addon_handle, 'tvshows')	
                if flinks:
                    for f in flinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='movies'		
                    xbmcplugin.setContent(addon_handle, typv)	
            
                if pagin:
            
                    for f in pagin:	
            
                        mud2 = 'SimplelistSeriale:%s'%mode2
                        if 'cda-filmy' in f.get('url') or 'zalukaj' in f.get('url') or 'anyvideo.org' in f.get('url'):
                            mud2 = 'ListContent:%s'%mode2
                        elif 'dudeplayer' in f.get('url'):
                            mud2 = 'ListContent3'
                        elif 'result_from' in f.get('url') and 'search_start' in f.get('url'):
                            mud2 = 'listsearchkino'
                        elif '_wpsearch' in f.get('url') and 'taxonomy' in f.get('url'):
                            mud2 = 'listsearchfilevids'
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
                    
                xbmcplugin.endOfDirectory(addon_handle)
            elif not flinks and not slinks:
                return
            else:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
            
        elif 'getVid' in mode:
            import resolveurl
        
            adapt = False
            mode2 = mode.split(':')[1]
            mod = import_mod(mode2)
        
            stream_url, resolve, kopiujlink,pobid = mod.getVideo(exlink, name)
        
            if resolve == 'quit':
                # Użytkownik anulował wybór źródła — kończymy
                xbmc.log("[ROMEJROTV] Użytkownik anulował wybór źródła", xbmc.LOGERROR)
                return
        
            try:
                stream_url = resolveurl.resolve(stream_url)
            except Exception as e:
                xbmc.log(f"[ROMEJROTV] Błąd przy resolveurl: {e}", xbmc.LOGERROR)
                stream_url = ''
                adapt = True
        
            if 'token' in kopiujlink or '.mkv' in kopiujlink or '.odycdn.com' in kopiujlink:
                PlayVid(kopiujlink, adapt)
                return
            if 'tb7_search' in kopiujlink:
                szukaj_tb7(name, year="")
                return
            if stream_url:
                adapt = True if '.m3u8' in stream_url else True
                PlayVid(stream_url, adapt)
        
                # Obsługa ID do recently_view i obejrzany_dodaj
                if '?id=' in exlink:
                    splitexl = exlink.split('?id=')[1]
                elif 'sezon=' in exlink and 'odcinek=' in exlink:
                    try:
                        splitexl = pobid
                    except:
                        splitexl = "nieznany"
                else:
                    splitexl = "nieznany"
        
                # Zapisz jako recently viewed
                if 'pokazs' in exlink:
                    recently = ['s-' + splitexl]
                else:
                    recently = [splitexl]
                recently_view(recently)
        
                if '[B][COLOR white]' in name:
                    obejrzany_dodaj(name, splitexl)
                    xbmc.executebuiltin('Container.Refresh')
        
                return  # <--- najważniejsze, kończymy działanie
        
            # Jeśli nie udało się nic znaleźć
            if 'api' in exlink:
                fname = f'{name} - {tvshowtitle}'
                nwlink(pobid, '1', kopiujlink, fname)
            elif 'pokazs' in exlink and 'id' in exlink:
                nwlink(pobid, '1', kopiujlink, name)
                
            else:
                nwlink(pobid, '0', kopiujlink, name)
        
            # if not stream_url:
            #     dialog = xbmcgui.Dialog()
            #     if dialog.yesno("RomejroTV", "Nie udało się odtworzyć źródła.\nCzy chcesz wybrać inne źródło?"):
            #         global season
            #         global episode
            #         encoded_exlink = urllib.parse.quote_plus(exlink)
            #         encoded_name = urllib.parse.quote_plus(name)
            #         encoded_tvshowtitle = urllib.parse.quote_plus(tvshowtitle if 'tvshowtitle' in globals() else '')
            #         encoded_opisb = urllib.parse.quote_plus(str(opisb))
            
            #         plugin_url = (
            #             f'{sys.argv[0]}?mode=getVid:romejrotv'
            #             f'&url={encoded_exlink}'
            #             f'&page=1'
            #             f'&moviescount=0'
            #             f'&movie=False'
            #             f'&name={encoded_name}'
            #             f'&season={season}'
            #             f'&episode={episode}'
            #             f'&tvshowtitle={encoded_tvshowtitle}'
            #             f'&tmdbid={tmdbid}'
            #             f'&mediatype=episode'
            #             f'&opisb={encoded_opisb}'
            #         )
            
            #         xbmc.log(f"➡️ Ponowne wywołanie: {plugin_url}", xbmc.LOGINFO)
            #         xbmc.executebuiltin(f'RunPlugin({plugin_url})')
            
            #     else:
            #         xbmcgui.Dialog().notification("RomejroTV", "Odtwarzanie anulowane", xbmcgui.NOTIFICATION_INFO, 3000)
            #     return

            
        elif 'ListContent' in mode:
            mode2 = mode.split(':')[1]
            
            mod = import_mod(mode2)
            flinks=[]
            slinks=[]
            pagin=[]
            flinks,slinks,pagin = mod.ListContent(exlink,page)
            if flinks or slinks:
                items1 = len(flinks)
                items2 = len(slinks)
                mud = 'getSimpleSeasons:%s'%mode2
                if slinks:
                    for f in slinks:
                        dd=f.get('plot') if f.get('plot') else f.get('title')
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
                    
                        
                    if 'romejrotv' in exlink:
                        xbmcplugin.setContent(addon_handle, 'videos')	
                    else:
                        if addon.getSetting('auto-view') == 'true':
                            typv='tvshows'
                        xbmcplugin.setContent(addon_handle, typv)
                        #xbmcplugin.setContent(addon_handle, 'tvshows')
                if flinks:
                    for f in flinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, fanart=f.get('image'), infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code'),'duration':f.get('duration')}, itemcount=items1)
                    if 'romejrotv' in exlink:
                        xbmcplugin.setContent(addon_handle, 'videos')	
                    else:
                        if addon.getSetting('auto-view') == 'true':
                            typv='movies'
                        xbmcplugin.setContent(addon_handle, typv)
                        #xbmcplugin.setContent(addon_handle, 'movies')
                        
                    
                if pagin:
                    for f in pagin:	
                        add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
                    
                xbmcplugin.endOfDirectory(addon_handle)
            else:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
                
        
        elif 'getSimpleSeasons'in mode:
            mode2 = mode.split(':')[1]
            mod = import_mod(mode2)
            seasons=mod.getSerial(exlink)	
            if seasons:
                items = len(seasons)
                for i in sorted(seasons.keys()):
                    opis=(seasons[i])[0].get('plot')
                    add_item(name=name+' - '+i, url=urllib_parse.quote_plus(str(seasons[i])), mode='getEpisodes:%s'%mode2, image=rys, folder=True,  infoLabels={'plot':opis}, itemcount=items)	
                if addon.getSetting('auto-view') == 'true':
                    typv='tvshows'		
                xbmcplugin.setContent(addon_handle, typv)	
                #xbmcplugin.setContent(addon_handle, 'tvshows')
                
                xbmcplugin.endOfDirectory(addon_handle)
            else:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak odcinków do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
        elif 'getEpisodes'in mode:
            mode2 = mode.split(':')[1]
            
            getEpisodes(exlink,mode2)
            
        # elif mode == 'create_player':
        #     # Ignoruj dane TMDb – na sztywno pokaż źródła
        #     xbmcgui.Dialog().notification('RomejroTV', 'Test – statyczna lista źródeł', xbmcgui.NOTIFICATION_INFO, 3000, False)
        
        #     # Lista testowych źródeł (linki muszą prowadzić do stron które rozumie Twój addon)
            

        elif mode == 'create_player':
            import requests
            import urllib3
            api_key = 'a07324c669cac4d96789197134ce272b'
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            query_variants = []
            tmdb_id = params.get('tmdb_id', '').strip()
            media_type = params.get('type', '').strip()
            mode = params.get('mode', '').strip()
            season = params.get('season', '').strip()
            episode = params.get('episode', '').strip()

            if not tmdb_id or not media_type:
                xbmcgui.Dialog().notification('RomejroTV', 'Brak wymaganych danych TMDb', xbmcgui.NOTIFICATION_ERROR, 3000)
                return
        
            
            if media_type == 'movie':
                url = f'https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={api_key}&language=pl-PL'
            else:
                url = f'https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season}/episode/{episode}?api_key={api_key}&language=pl-PL'
                show_url = f'https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={api_key}&language=pl-PL'
            
            try:
                r = requests.get(url, verify=False)
                r.raise_for_status()
                data = r.json()
                
                title = data.get('title') or data.get('name')
                original_title = data.get('original_title')
                year = (data.get('release_date') or data.get('first_air_date') or '')[:4]
            
                # Jeśli to serial, pobierz nazwę serialu
                if media_type != 'movie':
                    show_data = requests.get(show_url, verify=False).json()
                    showname = show_data.get('name')
                    original_name = show_data.get('original_name')
                    query_variants = [
                        f'{showname}',  # np. "Teoria wielkiego podrywu"
                        f'{original_name}',  # np. "The Big Bang Theory"
                        f'{showname} / {original_name}',  # "Teoria wielkiego podrywu / The Big Bang Theory"
                        f'{original_name} / {showname}',  # "The Big Bang Theory / Teoria wielkiego podrywu"
                        f'SEARCH::{original_name}'  # specjalna opcja - wyszukiwanie przez search.php
                        
                        
                    ]

                else:
                    showname = title
            
            except Exception as e:
                xbmcgui.Dialog().notification('RomejroTV', 'Błąd TMDb: ' + str(e), xbmcgui.NOTIFICATION_ERROR, 4000)
                return

        
            sources = ['romejrotv']  # dodaj inne źródła jeśli chcesz
            results = []
            flinks = []
            slinks = []
            
            if media_type == 'movie':
                for source in sources:
                    mod = import_mod(source)
                    if not mod:
                        continue
                    try:
                        # Lista prób wyszukiwania
                        search_variants = [
                            f"/ {original_title} ({year})",
                            f"{original_title} ({year})",
                            original_title,
                            title
                        ]
                        
                        flinks, slinks, pagin = [], [], []
            
                        for query in search_variants:
                            try:
                                xbmc.log(f'RomejroTV: Query: {query}', xbmc.LOGWARNING)
                                f, s, p = mod.szukcd(query)
                                if media_type == 'movie' and f:
                                    flinks, slinks, pagin = f, s, p
                                    break
                                elif media_type == 'tv' and s:
                                    flinks, slinks, pagin = f, s, p
                                    break
                            except Exception as e:
                                xbmc.log(f'RomejroTV: Błąd wyszukiwania w źródle {source} dla "{query}": {e}', xbmc.LOGWARNING)
            
                        if media_type == 'movie':
                            results += flinks or []
                        elif media_type == 'tv':
                            results += slinks or []
            
                    except Exception as e:
                        xbmc.log(f'RomejroTV: Błąd źródła {source}: {e}', xbmc.LOGWARNING)
            
                if not results:
                    xbmcgui.Dialog().notification('Nie znaleziono', f'Brak {original_title} w bazie danych :(', xbmcgui.NOTIFICATION_WARNING, 3000)
                    tity = f'{title} ({year})'
                    nontitle('0', tity)
                    return

            
            
            # if media_type == 'movie':
            #     for source in sources:
            #         mod = import_mod(source)
            #         if not mod:
            #             continue
            #         try:
            #             flinks, slinks, pagin = mod.szukcd(original_title+' ('+year+')')
                        
            #             if media_type == 'movie':
            #                 results += flinks or []
            #             elif media_type == 'tv':
            #                 results += slinks or []
                            
            #         except Exception as e:
            #             flinks, slinks, pagin = [], [], []
            #             xbmc.log(f'RomejroTV: Błąd źródła {source}: {e}', xbmc.LOGWARNING)
            
            #     if not results:
            #         xbmcgui.Dialog().notification('Nie znaleziono', f'Brak {original_title} w bazie danych :(', xbmcgui.NOTIFICATION_WARNING, 3000)
            #         tity = f'{title} ({year})'
            #         nontitle('0', tity)
            #         return
        
            # ✅ Odtwarzaj pierwszy znaleziony link
            if media_type=='tv':
                seasonro = str(season).zfill(2)
                for query in query_variants:
                    if query.startswith('SEARCH::'):
                        # obsługa wyszukiwania alternatywnego przez search.php
                        search_title = query[len('SEARCH::'):].strip()
                        encoded_search_title = urllib.parse.quote(search_title,safe='')
                        search_url = f'{DOMENA}search.php?phrase={encoded_search_title}'
            
                        try:
                            search_response = requests.get(search_url, timeout=5, verify=False)
                            if search_response.status_code == 200:
                                html = search_response.text
                                # parsowanie pierwszego tytułu z wyników z cmf3.parseDOM (tak jak wcześniej)
                                divs = parseDOM(html, 'div', attrs={'class': 'col-sm-4'})
                                if not divs:
                                    continue
            
                                first_div = divs[0]
                                titles = parseDOM(first_div, 'div', attrs={'class': 'title'})
                                if not titles:
                                    continue
            
                                first_title = titles[0].strip()
                                if first_title.startswith('(S)'):
                                    first_title = first_title[3:].strip()
                                first_title = first_title.rstrip('.').strip()
                                fixed_title_pl = first_title.encode("latin1").decode("utf-8")
                                encoded_first_title = urllib.parse.quote(fixed_title_pl, safe='')
                                
                                formatted_url = f'{DOMENA}pokazs.php?api=1&tytul={encoded_first_title}&sezon={seasonro}&odcinek={episode}'
                                new_response = requests.get(formatted_url, timeout=3, verify=False)
                                if new_response.status_code == 200 and 'link' in new_response.text.lower():
                                    test_sources = [{
                                        'title': showname,
                                        'url': formatted_url,
                                        'image': '',
                                        'season': season,
                                        'episode': episode,
                                        'tvshowtitle': title,
                                        'tmdbid': tmdb_id,
                                        'mediatype': 'episode',
                                        'plot': data.get('overview', '')
                                    }]
                                    
                                    break
                            else:
                                continue
                        except Exception:
                            continue
                    
                    else:
                        encoded_title = urllib.parse.quote(query, safe='')
                        formatted_url = f'{DOMENA}pokazs.php?api=1&tytul={encoded_title}&sezon={seasonro}&odcinek={episode}'
                        try:
                            response = requests.get(formatted_url, timeout=3, verify=False)
                            if response.status_code == 200 and 'link' in response.text.lower():
                                test_sources = [{
                                    'title': showname,
                                    'url': formatted_url,
                                    'image': '',
                                    'season':season,
                                    'episode':episode,
                                    'tvshowtitle': title,
                                    'tmdbid':tmdb_id,
                                    'mediatype':'episode',
                                    'plot': data.get('overview', '')
                                }]
                                break
                        except Exception as e:
                            continue
                else:
                    xbmcgui.Dialog().notification('Nie Znaleziono', f'Brak S{season}E{episode} - {title} w bazie danych :(', xbmcgui.NOTIFICATION_WARNING, 4000)
                    tity = f'S{season}E{episode} - {original_name} / {showname}'
                    nontitle('1', tity)
                    xbmc.log(f"Szukanie dodatkowe: {formatted_url}", xbmc.LOGINFO)
                    return

            
                for source in test_sources:
                    if autoplay == "false":
                        xbmcgui.Dialog().notification('RomejroTV', 'Wybierz Źródło...', xbmcgui.NOTIFICATION_INFO, 8000)
                    else:
                        progress = xbmcgui.DialogProgress()
                        progress.create("ROMEJROTV", "Odtwarzam...")
                        progress.update(100)
                    add_item(
                        name=source['title'],
                        url=source['url'],
                        mode='getVid:romejrotv',
                        image=source['image'],
                        folder=False,
                        IsPlayable=False,
                        fanart=source['image'],
                        movie=False,  # ← jeśli to odcinek, a nie film
                        season=int(source['season']) if source.get('season') else None,
                        episode=int(source['episode']) if source.get('episode') else None,
                        tvshowtitle=source.get('tvshowtitle'),
                        tmdbid=source.get('tmdbid'),
                        mediatype=source.get('mediatype', 'episode'),
                        infoLabels={
                            'plot': source['plot'],
                            'title': source['title']  # ← ważne, by był tytuł, nie tylko season/episode
                        }
                    )

            
                xbmcplugin.setContent(addon_handle, 'episodes')
                xbmcplugin.endOfDirectory(addon_handle)
            pagin = ''
            
            if flinks or slinks:
                items1 = len(flinks)
                items2 = len(slinks)
                mud = 'getSimpleSeasons:romejrotv'
                mode = 'romejrotv'
                
                
                if flinks:
                    for f in flinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode='getVid:romejrotv', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='movies'		
                    xbmcplugin.setContent(addon_handle, typv)	
            
                if pagin:
            
                    for f in pagin:	
            
                        mud2 = 'SimplelistSeriale:%s'%mode2
                        if 'cda-filmy' in f.get('url') or 'zalukaj' in f.get('url') or 'anyvideo.org' in f.get('url'):
                            mud2 = 'ListContent:%s'%mode2
                        elif 'dudeplayer' in f.get('url'):
                            mud2 = 'ListContent3'
                        elif 'result_from' in f.get('url') and 'search_start' in f.get('url'):
                            mud2 = 'listsearchkino'
                        elif '_wpsearch' in f.get('url') and 'taxonomy' in f.get('url'):
                            mud2 = 'listsearchfilevids'
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
                    
                xbmcplugin.endOfDirectory(addon_handle)
        elif not flinks and not slinks:
            return
        else:
            xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)


    else:
        home()
        xbmcplugin.endOfDirectory(addon_handle)	
if __name__ == '__main__':
	router(sys.argv[2][1:])
	init_storage()