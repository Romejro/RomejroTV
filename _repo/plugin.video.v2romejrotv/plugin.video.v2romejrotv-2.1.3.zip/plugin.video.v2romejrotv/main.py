import sys,re,os

import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc, xbmcvfs
import six
import sqlite3
from six.moves import urllib_parse



base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict( urllib_parse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.v2romejrotv')

xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL, label2Mask = "%R, %P, %Y")
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LASTPLAYED, label2Mask = "%R, %P, %Y")


PATH = addon.getAddonInfo('path')

if sys.version_info >= (3,0,0):
	DATAPATH		= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
else:
	DATAPATH		= xbmc.translatePath(addon.getAddonInfo('profile'))

if isinstance(DATAPATH, bytes):
	DATAPATH = DATAPATH.decode('Latin_1')
if isinstance(PATH, bytes):
	PATH = PATH.decode('Latin_1')
	
RESOURCES	   = PATH+'/RESOURCES/'
napisy = os.path.join(DATAPATH,'napisy')
DOMENA = 'https://romejrotv.blu24.pl/'
conn = sqlite3.connect(PATH+'/database.db')
cursor = conn.cursor()

FANART=PATH+'/fanart.jpg'
sys.path.append( os.path.join( RESOURCES, "lib" ) )

exlink = params.get('url', None)
name= params.get('name', None)
page = params.get('page','')
mcount= params.get('moviescount', None)
movie= params.get('movie', None)
rys= params.get('image', None)

try:
    opisb = eval(params.get('opisb', None))
except:
    opisb = params.get('opisb', None)
UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'

def build_url(query):
	return base_url + '?' + urllib_parse.urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, fanart=None, infoLabels=False, movie=True, itemcount=1, page=1, moviescount=0, playcount=0):
	list_item = xbmcgui.ListItem(name)

	if IsPlayable:
		list_item.setProperty("IsPlayable", 'True')

	if not infoLabels:
		infoLabels = {'title': name, 'plot': name}

	# Dodaj playcount i mediatype
	infoLabels['playcount'] = playcount
	infoLabels['mediatype'] = 'episode' if not movie else 'movie'

	list_item.setInfo(type="video", infoLabels=infoLabels)
	list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': image})

	# Nie musisz, ale możesz dodać:
	# list_item.setProperty('overlay', str(xbmcgui.ICON_OVERLAY_WATCHED))

	ok = xbmcplugin.addDirectoryItem(
		handle=addon_handle,
		url=build_url({'mode': mode, 'url': url, 'page': page, 'moviescount': moviescount, 'movie': movie, 'name': name, 'image': image, 'opisb': infoLabels}),
		listitem=list_item,
		isFolder=folder
	)
	return ok


def nwlink(di,rodzaj,link,tytul):
    import requests
    import datetime
    czas = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    idpob = di.split('?id=')[1]
    tytul_czysty = re.sub(r'B|/B|COLOR white|COLOR green|\/COLOR|[\[\]]', '', tytul)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = {
        'idsf': idpob,
        'rodzaj': rodzaj,
        'link': link,
        'czas': czas,
        'tytul': tytul_czysty.strip()
    }
    response = requests.post('https://romejrotv.blu24.pl/notwork.php?dodaj=ok', data=data, headers=headers)
    xbmcgui.Dialog().notification('[B]Link nie działa[/B]', 'Spróbuj inny',xbmcgui.NOTIFICATION_INFO, 6000,False)


def obejrzany_dodaj(nazwaodc,idodc):
    # Otwieramy plik w trybie dopisywania
    # with open(PATH+'obejrzane.txt', 'a') as plik:
    #     plik.write(nazwaodc + '\n')  # Dodajemy rekord i nową linię
    cursor.execute('INSERT INTO Obejrzane (tytul, idodcinka) VALUES (?, ?)', (nazwaodc,idodc,))
    conn.commit()  # Zatwierdzenie zmian
def recently_view(idmovie):
    # Otwieramy plik w trybie dopisywania
    
    with open(PATH+'recently.txt', 'r+') as plik:
        # Odczytaj istniejącą zawartość
        zawartosc = plik.read().strip()  # Odczytaj zawartość i usuń białe znaki
        istniejące_pozycje = zawartosc.split(',') if zawartosc else []
        
        if 'pokazs' in idmovie:
            nowe_pozycje = 's-'+idmovie
        else:
            nowe_pozycje = idmovie
        # Dodaj nowe pozycje na początku
        wszystkie_pozycje = nowe_pozycje + istniejące_pozycje
        
        # Zachowaj maksymalnie 10 pozycji
        wszystkie_pozycje = wszystkie_pozycje[:50]
        
        # Zapisz zaktualizowaną listę do pliku
        plik.seek(0)  # Przesuń wskaźnik na początek pliku
        plik.write(','.join(wszystkie_pozycje) + '\n')
        plik.truncate()  # Utnij plik w przypadku, gdy nowa zawartość jest krótsza
        

def getEpisodes(seasons,mode2):
	import ast
	episodes = eval(urllib_parse.unquote_plus(seasons))
	items=len(episodes)
	xbmc.executebuiltin("Container.Refresh")
    
	for f in episodes: 
		ses=f.get('season')
		epp=f.get('episode')
		idlinku = f.get('idlin')
# 		tyt=f.get('title').split('Season')#[0]
        
# 		tyt2 = '%s - odc.%02d'%(name,epp)
# 		tyt = tyt[0] if tyt else tyt2
# 		try:
# 			tyt = tyt.encode('Latin_1')#.decode('utf-8')
# 		except:
# 			pass
		cursor.execute('SELECT EXISTS(SELECT * FROM obejrzane WHERE idodcinka = ?)', (idlinku,))
		exists = cursor.fetchone()[0]

        
		if exists:
		    tytul=f.get('titok').encode('Latin_1')
		    playcount=1
		else:
		    tytul=f.get('titnot').encode('Latin_1')
		    playcount=0
		
		add_item(name=tytul, url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot')}, itemcount=items, playcount=playcount)
	xbmcplugin.setContent(addon_handle, 'movies')	
	xbmcplugin.endOfDirectory(addon_handle)
def PlayVid(stream_url,adaptive=False):

	
	play_item = xbmcgui.ListItem(path=stream_url)
	try:
		play_item.setInfo(type="Video", infoLabels={"title": name,'plot':opisb['plot']})
		
		play_item.setArt({'thumb': rys, 'poster': rys, 'banner': rys, 'fanart': rys})
	except:
		pass
	play_item.setProperty("IsPlayable", "true")
	if adaptive:
		if six.PY2:
			play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
		else:
			if stream_url.endswith('.mkv'):
                # Bez inputstream.adaptive – zwykły plik wideo
			    play_item.setMimeType('video/x-matroska')
			    play_item.setProperty('IsPlayable', 'true')
			    xbmc.Player().play(stream_url, play_item)
			elif 'm3u8' in stream_url or 'hls' in stream_url:
                # Odtwarzanie HLS
			    play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
			    play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
			    play_item.setMimeType('application/vnd.apple.mpegurl')
			    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
			    xbmc.Player().play(stream_url, play_item)
			else:
                # Domyślnie – zwykły plik bez adaptive
			    play_item.setProperty('IsPlayable', 'true')
			    xbmc.Player().play(stream_url, play_item)
# 			if 'token' in stream_url or 'mkv' in stream_url:
# 			    xbmc.Player().play(stream_url, play_item)
# 			else:
# 			    play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
# 			    play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
# 			    play_item.setMimeType('application/vnd.apple.mpegurl')
# 			    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
# 			    player = xbmc.Player()
# 			    player.play(stream_url, play_item)
		#play_item.setContentLookup(False)
	#else:
	#		#play_item = xbmcgui.ListItem(path=stream_url,label=tytul)
	#		#play_item.setInfo(type="Video", infoLabels={"title": tytul,'plot':tytul})
	#		#
	#		#if '.mp4' in stream_url:
	#	play_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
	#	play_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp4')
	#	play_item.setContentLookup(False)
	#	play_item.setMimeType('video/mp4')
	#	play_item.setProperty('mimetype', 'video/mp4')
	#	play_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
	#	play_item.setProperty('inputstream.ffmpegdirect.mime_type', 'video/mp4')
	#	play_item.setContentLookup(False)
  #	# xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
  
  
def import_mod(s):
	mod = {}
	if   s == 'romejrotv': import romejrotv	 as mod
	
	return mod
	
def home():

	add_item(DOMENA+'kodi.php', '[B][COLOR red]Filmy[/COLOR][/B]', 'DefaultMovies.png', "ListContent:romejrotv", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item(DOMENA+'series/index/', '[B][COLOR red]Seriale[/COLOR][/B]', 'DefaultMovies.png', "ListContent:romejrotv", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item('', '[B][COLOR red]Ustawienia[/COLOR][/B]', 'DefaultAddonsSettings.png', "Ustawienia", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item('', '[B][COLOR red]Kategorie[/COLOR][/B]', 'DefaultMovies.png', "Kategorie", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item('', '[B][COLOR red]Ostatnio Oglądane[/COLOR][/B]', 'DefaultMovies.png', "recentlyview", folder=True,fanart=RESOURCES+'fanart.jpg')
	add_item('', '[B][COLOR red]Szukaj[/COLOR][/B]', 'DefaultAddonsSearch.png', "SimplelistSearch:romejrotv", folder=True,fanart=RESOURCES+'fanart.jpg')


def router(paramstring):
    
    params = dict( urllib_parse.parse_qsl(paramstring))
    if params:
        typv='videos'
        mode = params.get('mode', None)
        if 'Ustawienia' in mode:
            add_item('', '[B][COLOR red]Resetuj obejrzane odcinki[/COLOR][/B]', 'DefaultAddonsSettings.png', "Ustawienia", folder=True,fanart=RESOURCES+'fanart.jpg')
            xbmcplugin.setContent(addon_handle, typv)
            xbmcplugin.endOfDirectory(addon_handle)
        elif 'Kategorie' in mode:
            add_item('', '[B][COLOR red]Akcja[/COLOR][/B]', DOMENA+'kat/akcja.jpg', "kate:akcja", folder=True,fanart=DOMENA+'fanart.jpg')
            add_item('', '[B][COLOR red]Sensacyjny[/COLOR][/B]', DOMENA+'kat/sensacyjny.jpg', "kate:sensacyjny", folder=True,fanart=DOMENA+'fanart.jpg')
            add_item('', '[B][COLOR red]Obyczajowy[/COLOR][/B]', DOMENA+'kat/obyczajowy.jpg', "kate:obyczajowy", folder=True,fanart=DOMENA+'fanart.jpg')
            add_item('', '[B][COLOR red]Komedia[/COLOR][/B]', DOMENA+'kat/komedia.jpg', "kate:komedia", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Dramat[/COLOR][/B]', DOMENA+'kat/dramat.jpg', "kate:dramat", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Animacja[/COLOR][/B]', DOMENA+'kat/animacja.jpg', "kate:animacja", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Przygodowy[/COLOR][/B]', DOMENA+'kat/przygodowy.jpg', "kate:przygodowy", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Sci-Fi[/COLOR][/B]', DOMENA+'kat/scifi.jpg', "kate:sci-fi", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Familijny[/COLOR][/B]', DOMENA+'kat/familijny.jpg', "kate:familijny", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Horror[/COLOR][/B]', DOMENA+'kat/horror.jpg', "kate:horror", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Thirller[/COLOR][/B]', DOMENA+'kat/thirller.jpg', "kate:thirller", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Dokumentalny[/COLOR][/B]', DOMENA+'kat/dokumentalny.jpg', "kate:dokumentalny", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Dla Dzieci[/COLOR][/B]', DOMENA+'kat/dladzieci.jpg', "kate:dla dzieci", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Komedia Romantyczna[/COLOR][/B]', DOMENA+'kat/komediarom.jpg', "kate:komedia rom", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            add_item('', '[B][COLOR red]Romans[/COLOR][/B]', DOMENA+'kat/romans.jpg', "kate:romans", folder=True,fanart=DOMENA+'kat/fanart.jpg')
            
            xbmcplugin.setContent(addon_handle, typv)
            xbmcplugin.endOfDirectory(addon_handle)
        elif 'kate' in mode:
            kateg = mode.split(':')[1]
            mod = import_mod('romejrotv')
            linked = DOMENA+'search.php?phrase='+kateg
            flinks,slinks,pagin = mod.ListContentSearch(linked,page)
        
            if flinks or slinks:
                items1 = len(flinks)
                items2 = len(slinks)
                mud = 'getSimpleSeasons:romejrotv'
                
                if slinks:
                    for f in slinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='tvshows'		
                    xbmcplugin.setContent(addon_handle, typv)	
                    #xbmcplugin.setContent(addon_handle, 'tvshows')	
                if flinks:
                    for f in flinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode='getVid:romejrotv', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='movies'		
                    xbmcplugin.setContent(addon_handle, typv)	
        
                                
                xbmcplugin.endOfDirectory(addon_handle)
            elif not flinks and not slinks:
                return
            else:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
        elif 'recentlyview' in mode:
            filename = PATH+'recently.txt'
            
            # Krok 2: Odczytaj zawartość
            with open(filename, 'r', encoding='utf-8') as file:
                content = file.read()  # lub file.readlines() jeśli wolisz
            
            # Krok 3: Rozbij tekst do tablicy po przecinku
            data_array = content.split(',')
            
            # Usunięcie zbędnych spacji z każdego elementu
            data_array = [item.strip() for item in data_array]
            film = [item if item != '' else '0' for item in data_array]
            link = ','.join(film)
            mod = import_mod('romejrotv')
            linked = DOMENA+'recently.php?pokaz='+link
            flinks,slinks,pagin = mod.RecentlyView(linked,page)
            
            if flinks or slinks:
                items1 = len(flinks)
                items2 = len(slinks)
                mud = 'getSimpleSeasons:romejrotv'
                
                if slinks:
                    for f in slinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='tvshows'		
                    xbmcplugin.setContent(addon_handle, typv)	
                    #xbmcplugin.setContent(addon_handle, 'tvshows')	
                if flinks:
                    for f in flinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode='getVid:romejrotv', image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='movies'		
                    xbmcplugin.setContent(addon_handle, typv)	
            
                		
                    
                xbmcplugin.endOfDirectory(addon_handle)
            elif not flinks and not slinks:
                return
            else:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
                
        elif 'SimplelistSearch' in mode:
            mode2 = mode.split(':')[1]
            mod = import_mod(mode2)
            
            flinks,slinks,pagin = mod.ListSearch(exlink,page)
            
            if flinks or slinks:
                items1 = len(flinks)
                items2 = len(slinks)
                mud = 'getSimpleSeasons:%s'%mode2
                
                if mode2=='filmeriaco':
                    mud = 'getLinksfilmeriaco'
                
                elif mode2 =='kinomoc':
                    mud = 'Listepisodeskinomoc'
                if slinks:
                    for f in slinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':f.get('plot')}, itemcount=items2, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='tvshows'		
                    xbmcplugin.setContent(addon_handle, typv)	
                    #xbmcplugin.setContent(addon_handle, 'tvshows')	
                if flinks:
                    for f in flinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code')}, itemcount=items1, fanart=f.get('image'))
                    if addon.getSetting('auto-view') == 'true':
                        typv='movies'		
                    xbmcplugin.setContent(addon_handle, typv)	
            
                if pagin:
            
                    for f in pagin:	
            
                        mud2 = 'SimplelistSeriale:%s'%mode2
                        if 'cda-filmy' in f.get('url') or 'zalukaj' in f.get('url') or 'anyvideo.org' in f.get('url'):
                            mud2 = 'ListContent:%s'%mode2
                        elif 'dudeplayer' in f.get('url'):
                            mud2 = 'ListContent3'
                        elif 'result_from' in f.get('url') and 'search_start' in f.get('url'):
                            mud2 = 'listsearchkino'
                        elif '_wpsearch' in f.get('url') and 'taxonomy' in f.get('url'):
                            mud2 = 'listsearchfilevids'
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
                    
                xbmcplugin.endOfDirectory(addon_handle)
            elif not flinks and not slinks:
                return
            else:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
        elif 'menu' in mode:
            mode2 = mode.split(':')[1]
            mod = import_menu(mode2)
            mod
            xbmcplugin.endOfDirectory(addon_handle)
            
        elif 'getVid' in mode:
            import resolveurl
            #busy()
            adapt=False
            mode2 = mode.split(':')[1]
            mod = import_mod(mode2)
            #idle()
            stream_url,resolve,kopiujlink = mod.getVideo(exlink)
            
            try:
                stream_url = resolveurl.resolve(stream_url)
            except Exception as e:
                stream_url=''
                adapt= True
                
            if 'token' in kopiujlink or '.mkv' in kopiujlink:
                PlayVid(kopiujlink,adapt)
            else:    
                if stream_url:
                    adapt = True if '.m3u8' in stream_url else True
                    PlayVid(stream_url,adapt)
                    splitexl = exlink.split('?id=')[1]
                    if 'pokazs' in exlink:
                        recently = ['s-'+splitexl]
                    else:
                        recently = [splitexl]
                    recently_view(recently)
                    if '[B][COLOR white]' in name:
                        obejrzany_dodaj(name,splitexl)
                        xbmc.executebuiltin('Container.Refresh')
                else:
                    if resolve=='quit':
                        if 'pokazs' in exlink:
                            nwlink(exlink,'1',kopiujlink,name)
                        else:
                            nwlink(exlink,'0',kopiujlink,name)
                        quit()
                    else:
                        if 'pokazs' in exlink:
                            nwlink(exlink,'1',kopiujlink,name)
                        else:
                            nwlink(exlink,'0',kopiujlink,name)
            
        elif 'ListContent' in mode:
            mode2 = mode.split(':')[1]
            
            mod = import_mod(mode2)
            flinks=[]
            slinks=[]
            pagin=[]
            flinks,slinks,pagin = mod.ListContent(exlink,page)
            if flinks or slinks:
                items1 = len(flinks)
                items2 = len(slinks)
                mud = 'getSimpleSeasons:%s'%mode2
                if slinks:
                    for f in slinks:
                        dd=f.get('plot') if f.get('plot') else f.get('title')
                        add_item(name=f.get('title'), url=f.get('url'), mode=mud, image=f.get('image'), folder=True, infoLabels={'plot':dd,'title': f.get('title')}, itemcount=items2)
                    
                        
                    if 'romejrotv' in exlink:
                        xbmcplugin.setContent(addon_handle, 'videos')	
                    else:
                        if addon.getSetting('auto-view') == 'true':
                            typv='tvshows'
                        xbmcplugin.setContent(addon_handle, typv)
                        #xbmcplugin.setContent(addon_handle, 'tvshows')
                if flinks:
                    for f in flinks:
                        
                        add_item(name=f.get('title'), url=f.get('url'), mode='getVid:%s'%mode2, image=f.get('image'), folder=False, IsPlayable=False, fanart=f.get('image'), infoLabels={'plot':f.get('plot'),'year':f.get('year'),'genre':f.get('genre'),'code':f.get('code'),'duration':f.get('duration')}, itemcount=items1)
                    if 'romejrotv' in exlink:
                        xbmcplugin.setContent(addon_handle, 'videos')	
                    else:
                        if addon.getSetting('auto-view') == 'true':
                            typv='movies'
                        xbmcplugin.setContent(addon_handle, typv)
                        #xbmcplugin.setContent(addon_handle, 'movies')
                        
                    
                if pagin:
                    for f in pagin:	
                        add_item(name=f.get('title'), url=f.get('url'), mode='ListContent:%s'%mode2, image=RESOURCES+'nextpage.png', folder=True,page=f.get('page'))				
                    
                xbmcplugin.endOfDirectory(addon_handle)
            else:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak materiałów do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
                
        
        elif 'getSimpleSeasons'in mode:
            mode2 = mode.split(':')[1]
            mod = import_mod(mode2)
            seasons=mod.getSerial(exlink)	
            if seasons:
                items = len(seasons)
                for i in sorted(seasons.keys()):
                    opis=(seasons[i])[0].get('plot')
                    add_item(name=name+' - '+i, url=urllib_parse.quote_plus(str(seasons[i])), mode='getEpisodes:%s'%mode2, image=rys, folder=True,  infoLabels={'plot':opis}, itemcount=items)	
                if addon.getSetting('auto-view') == 'true':
                    typv='tvshows'		
                xbmcplugin.setContent(addon_handle, typv)	
                #xbmcplugin.setContent(addon_handle, 'tvshows')
                
                xbmcplugin.endOfDirectory(addon_handle)
            else:
                xbmcgui.Dialog().notification('[B]Uwaga[/B]', 'Brak odcinków do wyświetlenia',xbmcgui.NOTIFICATION_INFO, 6000,False)
        elif 'getEpisodes'in mode:
            mode2 = mode.split(':')[1]
            
            getEpisodes(exlink,mode2)

    else:
        home()
        xbmcplugin.endOfDirectory(addon_handle)	
if __name__ == '__main__':
	router(sys.argv[2][1:])