# -*- coding: UTF-8 -*-
import sys,re,os, json
import geturl as gethtml
from geturl import PLchar as PLchar

if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus, unquote_plus
    import urllib.parse as urlparse
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus, unquote_plus
    import urlparse

basurl='https://kinomoc.com'
UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'

def ListContent(url,page):
	if '/page/' in url:
		nturl = re.sub('page\/\\d+','page/%d'%(int(page)+1),url)
		url = re.sub('page\/\\d+','page/%d'%int(page),url)
	else:
		nturl = url + 'page/%d' %(int(page)+1)
		url = url + 'page/%d' %int(page)
		
	html,kuks = gethtml.getRequests(url)
	npage=[]
	fout=[]
	sout=[]
	if html.find(nturl)>-1:
		npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})

	result = parseDOM(html,'div', attrs={'id': "dle-content"})
	result = result[0] if result else html
	ids = [(a.start(), a.end()) for a in re.finditer('<article', result)]
	ids.append( (-1,-1) )

	for i in range(len(ids[:-1])):
		subset = result[ ids[i][1]:ids[i+1][0]]

		href = parseDOM(subset, 'a', ret='href')[0]
		imag = parseDOM(subset, 'img', ret='src')[0]
		imag = basurl+ imag if imag.startswith('/') else imag
		opis = parseDOM(subset,'div', attrs={'class': "texto"})
		opis = opis[0] if opis else ''
		tytul = parseDOM(subset,'h3', attrs={'class': "poster__title"})[0]
		tytul = re.sub("<[^>]*>","",tytul.strip()).replace(',Online za darmo', '')
		year = ''
		kateg = ''

		if '/filmy/' in 	url:
			fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})	
		else:
			sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})

	return fout,sout,npage

def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	
	
def getSerial(url):

	html,kuks = gethtml.getRequests(url)
	maindata = parseDOM(html,'div', attrs={'class': "film\-bilgileri"})
	maindata = maindata[0] if maindata else html
	imag = parseDOM(maindata, 'img', ret='src')[0]  
	imag = basurl+ imag if imag.startswith('/') else imag
	tytul = parseDOM(maindata, 'h1')[0]
	tt = re.findall('icon\-hd"\s*title.*?>([^<]+)<',maindata,re.DOTALL)
	tt = tt[0] if tt else ''
	opis = parseDOM(maindata,'div', attrs={'class': "description"})
	opis = opis[0].split('<br><br>')[-1]
	opis = re.sub("<[^>]*>","",opis).split('\n\t\t\t')[-1]

	xfname = re.findall('data\-xfname\s*=\s*"([^"]+)',html,re.DOTALL)[0]
	news_id = re.findall('data\-news_id\s*=\s*"([^"]+)',html,re.DOTALL)[0]
	head = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer':url
	
	}
	
	str_url = 'https://kinomoc.com/engine/ajax/controller.php?mod=playlists&news_id='+str(news_id)+'&xfield='+xfname
	html,kuks = gethtml.getRequests(str_url,headers=head)
	episodes=[]
	try:
		jsdata = json.loads(html).get('response',None)
	except:
		jsdata = None
	if jsdata:
		seasons = re.findall('<li data\-id="([^"]+)">([^<]+)<\/li>',jsdata,re.DOTALL)

		for dt,ses in seasons:
			epis = re.findall('data\-file\s*=\s*"([^"]+)"\s*data\-id="'+dt+'">([^<]+)<\/li>',jsdata,re.DOTALL)
			for href,tyt2 in epis:

				tyt = ('[COLOR lightblue]%s[/COLOR] - [COLOR khaki](%s) %s[/COLOR]   [I][%s][/I]'%(tytul,ses,tyt2,tt.lower())).replace(',Online za darmo','')
				episodes.append({'title':PLchar(tyt),'url':PLchar(href+'|'+url),'image':imag,'plot':PLchar(opis)})#})


	return episodes

def getVideo(url):

	if 'chillx.top' in url:
		iframe,urlk = url.split('|')
		stream_url = decodeLink(iframe,urlk)
		return stream_url,False
	out=[]
	html,kuks = gethtml.getRequests(url)
	stream_url=''

	mess = parseDOM(html,'div', attrs={'class': "fmessage-in"})
	iframes = parseDOM(html, 'iframe', ret='src')
	stream_url =''
	for iframe in iframes:
		if not 'youtube.' in iframe and not 'imdb_' in iframe:
			stream_url = iframe
			break
	if stream_url:
		resol =True
		if mess:
			import xbmcgui
			xbmcgui.Dialog().notification('[B]Uwaga[/B]', mess[0],xbmcgui.NOTIFICATION_INFO, 6000,False)
		if 'chillx.top' in iframe:
			stream_url = decodeLink(iframe,url)
			resol = False

		return stream_url,resol
	else:
		return stream_url,'quit'
		
def decodeLink(iframe,url):
	import requests
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Referer':url
	
	}
	html = (requests.get(iframe, headers = headers,verify=False).text).replace("\'",'"')
	
	import base64
	import codecs
	import json
	import hashlib
	import binascii
	import pyaes
	decryptedData=''
	stream_url=''

	masterjs = re.findall('masterjs\s*=\s*"(.+?)"',html,re.DOTALL+re.I)[0]
	try:
		dane = json.loads(base64.b64decode(masterjs))
		ciphertext = dane['ciphertext']
		ciphertext=(base64.b64decode(ciphertext))
		salt = codecs.decode(dane['salt'], 'hex')
		iv = codecs.decode(dane['iv'], 'hex')
		iterations = dane['iterations']
		key = b'\x34\x56\x71\x45\x33\x23\x4e\x37\x7a\x74\x26\x48\x45\x50\x5e\x61'
		secret = hashlib.pbkdf2_hmac('sha512', key, salt, iterations, 32)
		decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(secret, iv))
		decryptedData = decrypter.feed(ciphertext).decode(encoding='utf-8', errors='strict')
		stream_url = re.findall('var source\s*=\s*"([^"]+)',decryptedData,re.DOTALL)[0]
		stream_url+='|User-agent='+UA+'&Referer='+url+'Origin='+url

	except:
		pass
	return stream_url
def szukcd(dt={}):
	import ast
	dt = ast.literal_eval(unquote_plus(dt))
	fout=[]
	sout=[]
	npagex=[]
	headers = {
		'User-Agent': UA,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
		'Origin': 'https://kinomoc.com',
		'Connection': 'keep-alive'
	}
	
	data = dt
	url ='https://kinomoc.com/index.php?do=search'
	html,kuks = gethtml.getRequests(url,data=data,headers=headers)

	npage = re.findall('<a onclick\=\"javascript\:list_submit\((\d+)\);',html,re.DOTALL)
	if npage:

		result_from=(int(npage[0])-1) * 15 + 1
		dtx = {'do': 'search','subaction': 'search','search_start': npage[0],'full_search': '0','result_from': str(result_from),'story': data.get('story', None)}
		dtx = quote_plus(str(dtx))
		npagex.append({'title':'Następna strona','url':dtx,'image':'','plot':''})
	ids = [(a.start(), a.end()) for a in re.finditer('<article', html)]
	ids.append( (-1,-1) )


	for i in range(len(ids[:-1])):
		subset = html[ ids[i][1]:ids[i+1][0]]
		if not 'story searchpage' in subset:
			href = parseDOM(subset, 'a', ret='href')[0]
			imag = parseDOM(subset, 'img', ret='src')[0]
			imag = basurl+ imag if imag.startswith('/') else imag
			opis = parseDOM(subset,'div', attrs={'class': "texto"})
			opis = opis[0] if opis else ''
			tytul = parseDOM(subset,'div', attrs={'class': "name"})[0]
			tytul = re.sub("<[^>]*>","",tytul.strip()).replace(',Online za darmo', '')
			opis = opis[0] if opis else tytul
			year = ''
			kateg = ''
			ttyp = parseDOM(subset,'div', attrs={'class': "category"})
			ttyp = ttyp[0].lower() if ttyp else ''
			tt3= parseDOM(subset,'span', attrs={'class': "icon-voicer"}) 
			tt3 = tt3[0].lower() if tt3 else ''

			if 'serial' in ttyp and 'sezon' in tt3:
				sout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})
			else:

				fout.append({'title':PLchar(tytul),'url':PLchar(href),'image':PLchar(imag),'plot':PLchar(opis),'year':year,'genre':PLchar(kateg)})	


	return fout,sout,npagex

def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:

		dt = {'do': 'search','subaction': 'search','search_start': '0','full_search': '0','result_from': '1','story': d.replace(' ','+'),}
		dt = quote_plus(str(dt))
		fout,sout,npage=szukcd(dt)

	return fout,sout,npage
