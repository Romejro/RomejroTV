import sys,re,os#, cookielib
import geturl as gethtml
import xbmc, xbmcaddon, xbmcvfs
import urllib.parse
import requests
import xbmcgui

addon = xbmcaddon.Addon(id='plugin.video.v2romejrotv')
PATH = addon.getAddonInfo('path')
if sys.version_info >= (3,0,0):
	DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))#.decode('utf-8')
else:
	DATAPATH        = xbmc.translatePath(addon.getAddonInfo('profile')).decode('Latin_1')
UA= 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0'
headers2 = {
	
		'Referer':'https://romejrotv.blu24.pl/pokaz.php',
		'user-agent': UA,
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
	}
cuk = gethtml.get_setting('dguardkukzaluknij')
if sys.version_info >= (3,0,0):
# for Python 3
    from cmf3 import parseDOM
    from cmf3 import replaceHTMLCodes
    from urllib.parse import parse_qs, quote, urlencode, quote_plus

    import http.cookiejar as cookielib
else:
    # for Python 2
    from cmf2 import parseDOM
    from cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    
from requests.compat import urlparse


cj ={}
kuksy2=''.join(['%s=%s;'%(c.name, c.value) for c in cj])
#conn.text_factory = lambda x: x.decode('latin_1')

basurl='https://romejrotv.blu24.pl'


def ListContent(url,page):
	
	if not '/series/index' in url:
	

		if '?page=' in url:

			nturlx = 'href="?page=%d"'%(int(page)+1) 

			url = re.sub('\?page\=\d+','?page=%d'%int(page),url)
			nturl = re.sub('\?page\=\d+','?page=%d'%(int(page)+1),url)

		else:
			nturlx = 'href="?page=%d"'%(int(page)+1) 

			url = url + '?page=%d' %int(page)
			nturl = re.sub('\?page\=\d+','?page=%d'%(int(page)+1),url)
	else:
		if 'series/index/strona=' in url:

			nturlx = 'href="strona=%d"'%(int(page)+1) 

			url = re.sub('strona=\d+','strona=%d'%int(page),url)
			nturl = re.sub('strona=\d+','strona=%d'%(int(page)+1),url)

		else:
			nturlx = 'href="strona=%d"'%(int(page)+1) 

			url = url + 'strona=%d' %int(page)
			nturl = re.sub('strona=\d+','strona=%d'%(int(page)+1),url)
		if '/?s=' in url:
			url = url

		
	if '/?s=' in url:
		url = re.sub('page\/\\d+','',url)

	html,kuks = gethtml.getRequests4(url, headers=headers2, cookies=cj)
	npage=[]
	fout=[]
	sout=[]
	if html.find(nturlx)>-1:
		npage.append({'title':'Następna strona','url':nturl,'image':'','plot':'','page':int(page)+1})

	result = parseDOM(html,'div', attrs={'id': "item\-list",'class': "row"})
	result = result[0] if result else html

	if not 'series/index' in url:
		links = parseDOM(result,'div', attrs={'class': "col\-xs\-\d+\s*col\-sm\-\d+\s*col\-lg\-\d+"}) 
	
		for link in links:
	
			href = parseDOM(link, 'a', ret='href')[0]
			imag = parseDOM(link, 'img', ret='src')[0]
			if 'seasons' in url:
				tytul = parseDOM(link, 'img', ret='alt')[0]
			else:
				tytul = parseDOM(link,'div', attrs={'class': "title"})
				tytul = tytul [0] if tytul else re.findall('>([^<]+)<\/a><\/h3>',link)[0]
			imag = 'https:'+ imag if imag.startswith('//') else imag
	
			opis = parseDOM(link,'div', attrs={'class': "texto"})
			opis = opis[0] if opis else tytul
			genre=''
			kateg =''
			jak = parseDOM(link,'span', attrs={'class': "quality"}) 
			jak = jak[0] if jak else ''
			trwa=''
			year = re.findall('\((\d+)\)',tytul)
			year = year[0] if year else ''
			tytul = tytul.encode('Latin_1')
			opis = opis.encode('Latin_1')
			if not year:
				year = re.findall('<\/h3>\s*<span>(\d+)<',link)
				year = year[0] if year else ''
			metdata = parseDOM(link,'div', attrs={'class': "metadata"})
			
	
			if 'tvshows' in url or 'seasons' in url or 'tvshows' in href:
				sout.append({'title':tytul,'url':href,'image':imag,'plot':opis,'year':year,'code':jak,'genre':kateg, 'duration':trwa, 'mode2':'dudaplayer'})
			else:
				fout.append({'title':tytul,'url':href,'image':imag,'plot':opis,'year':year,'code':jak,'genre':kateg, 'duration':trwa, 'mode2':'dudaplayer'})
	
	else:
		result  = parseDOM(result,'ul', attrs={'id': "series\-list",'class':'filter'}) [0]
		links = parseDOM(result,'li')
	
		for link in links:
	
			href = parseDOM(link, 'a', ret='href')[0]
			tytul  = parseDOM(link, 'a')[0]
			obraz = parseDOM(link, 'img', ret='src')[0]
			opis = parseDOM(link,'div', attrs={'class': "texto"})[0]
			tytul = tytul.encode('Latin_1')
			opis = opis.encode('Latin_1')
			sout.append({'title':tytul,'url':href,'image':obraz,'plot':opis,'year':'','code':'','genre':'', 'duration':'', 'mode2':'dudaplayer'})

	return fout,sout,npage

def getSerial(url):

    html,kuks = gethtml.getRequests4(url,headers=headers2, cookies=cj)
    resultmain = re.findall('item\-headline(.*?)fb\-like',html,re.DOTALL)[0]
    
    tytul = parseDOM(resultmain,'h2')[0]
    img  = parseDOM(resultmain, 'img', ret='src')
    img = img[0] if img else ''
    
    opis = tytul
    sesres = parseDOM(html,'ul', attrs={'id': "episode\-list"})[0]
    sezony = re.findall('(<span>.*?<\/ul>)',sesres,re.DOTALL)
    episodes=[]
    #
    for sezon in sezony:
    
        sesx = parseDOM(sezon,'span')
        if sesx:
            ses = re.findall('(\d+)',sesx[0],re.DOTALL)#[0]
            ses = ses[0] if ses else '0'
    
        eps = parseDOM(sezon,'li')
    
        
        for ep in eps:
    
            href = parseDOM(ep, 'a', ret='href')[0]  
            tyt2 = parseDOM(ep, 'a')[0] 
            opis = parseDOM(ep, 'div', attrs={'class': "opisodc"})[0]
            epis = re.findall('s\d+e(\d+)',tyt2)[0]
            idlink = href.split('?id=')[1]
            opis = opis.encode('Latin_1')
            fraza = '%s - [B][COLOR white] %s [/COLOR][/B]'%(tytul,tyt2)
            
            #znalezione = szukaj_obejrzane(fraza)
            
            
            obejrzany = '[B][COLOR green] %s [/COLOR][/B]'%(tyt2)
            nobejrzany = '[B][COLOR white] %s [/COLOR][/B] - %s'%(tyt2,tytul)
            
    # 			if znalezione:
    # 			    for rekord in znalezione:
    # 			        tyt = '[B][COLOR green] %s [/COLOR][/B]'%(tyt2)
    # 			else:
    # 			    tyt = '%s - [B][COLOR white] %s [/COLOR][/B]'%(tytul,tyt2)
    
            episodes.append({'titok':obejrzany,'titnot':nobejrzany,'url':href,'image':img,'plot':opis,'season':int(ses),'episode':int(epis), 'idlin':idlink})
            
            
    seasons = splitToSeasons(episodes)
    return seasons


def splitToSeasons(episodes):
    out={}
    seasons = [x.get('season') for x in episodes]
    for s in set(seasons):
        out['Sezon %02d'%s]=[episodes[i] for i, j in enumerate(seasons) if j == s]
    return out	

def RecentlyView(url, page):
    html, kuks = gethtml.getRequests4(url, headers=headers2, cookies=cj)
    npage = []
    results = []  # <--- jedna lista, zamiast fout/sout

    result = parseDOM(html, 'div', attrs={'id': "advanced\-search"})[0]
    links = parseDOM(result, 'div', attrs={'class': "col\-sm\-\d+"})

    for link in links:
        if 'href' in link:
            href = parseDOM(link, 'a', ret='href')[0]
            imag = parseDOM(link, 'img', ret='src')[0]

            tytul = parseDOM(link, 'div', attrs={'class': "title"})[0]
            opis = parseDOM(link, 'div', attrs={'class': "texto"})
            opis = opis[0] if opis else ''

            jak = ''
            kateg = ''
            trwa = ''
            year = ''

            tytul = tytul.encode('Latin_1')
            opis = opis.encode('Latin_1')
            imag += '|User-Agent=' + quote(UA) + '&Cookie=' + kuks[:-1]

            if 'serial-online' in href or 'seasons' in href:
                typ = 'serial'
            else:
                typ = 'film'

            results.append({
                'title': tytul,
                'url': href,
                'image': imag,
                'plot': opis,
                'year': year,
                'code': jak,
                'genre': kateg,
                'duration': trwa,
                'mode2': 'dudaplayer',
                'type': typ  # <--- dodajemy informację pomocniczą
            })

    return results, npage  # zwracamy jedną listę



def ListContentSearch(url,page):
	html,kuks = gethtml.getRequests4(url,headers=headers2, cookies=cj)
	npage=[]
	fout=[]
	sout=[]

	result = parseDOM(html,'div', attrs={'id': "advanced\-search"})[0]  
	links = parseDOM(result,'div', attrs={'class': "col\-sm\-\d+"})  

	for link in links:
		if 'href' in link:
			href = parseDOM(link, 'a', ret='href')[0]
			imag = parseDOM(link, 'img', ret='src')[0]

			tytul = parseDOM(link,'div', attrs={'class': "title"})[0]
			opis = parseDOM(link,'div', attrs={'class': "texto"})
			opis = opis[0] if opis else ''

			jak =''
			kateg =''
			trwa =''

			year =''
			tytul = tytul.encode('Latin_1')
			opis = opis.encode('Latin_1')

			imag+='|User-Agent='+quote(UA)+'&Cookie='+kuks[:-1]
			if 'serial-online' in href or 'seasons' in href:
				sout.append({'title':tytul,'url':href,'image':imag,'plot':opis,'year':year,'code':jak,'genre':kateg, 'duration':trwa, 'mode2':'dudaplayer'})
			else:
				fout.append({'title':tytul,'url':href,'image':imag,'plot':opis,'year':year,'code':jak,'genre':kateg, 'duration':trwa, 'mode2':'dudaplayer'})
	return fout,sout,npage

# def getVideo(url,title):

# 	out=[]
# 	html,kuks = gethtml.getRequests4(url,headers=headers2, cookies=cj)
# 	stream_url=''
# 	kopiujlink = ""
# 	pobid = ''
# 	result = parseDOM(html,'tbody')
# 	if result:
# 		result=result[0]
        
# 		pobids = parseDOM(result, 'td', attrs={'class': 'pobid'})
# 		
# 		if pobids:
# 		    pobid = pobids[0]  # tylko pierwszy
        
# 		videos = parseDOM(result,'tr')
# 		for vid in videos:
# 			wersje = parseDOM(vid, 'td', attrs={'class': 'wersja'})
# 			wersja = ' |'+wersje[0].strip()+'|' if wersje and wersje[0].strip() else ' '
            
# 			hosthref = re.findall(r'href="([^"]+)"', vid)
            
# 			for href in hosthref:
# 			    host = urlparse(href).netloc or "Brak hosta"
# 			    host += f' {wersja}'
# 			    out.append({'href': href, 'host': host})

                
# 		out.append({'href': 'tb7_search', 'host': 'Szukaj w TB7.pl'})
# 		if out:
# 			if len(out) > 1:
# 				u = [ x.get('href') for x in  out]
# 				h = [ x.get('host') for x in  out]
# 				sel = gethtml.selectDialog(title, h)
# 				href = out[sel].get('href') if sel>-1 else quit()
# 			else:
# 				href = out[0].get('href')
# 			if href:
# 				if 'token' in href or '.mkv' in href or 'tb7_search' in href:
# 				    kopiujlink = href
# 				else:
# 				    headers = {

# 					'user-agent': UA,
# 					'accept': '*/*',
# 					'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
# 					'x-requested-with': 'XMLHttpRequest',
# 					'referer': url,
# 					'cookie':cuk,
# 					'te': 'trailers',}
# 				    stream_url,kuks =gethtml.getRequestsRedirUrl(href,headers=headers)
# 				    kopiujlink = href
# 			else:
# 				return stream_url,'quit',kopiujlink, pobid
# 	return stream_url,True,kopiujlink,pobid


def getVideo(url, title):
    out = []
    html, kuks = gethtml.getRequests4(url, headers=headers2, cookies=cj)
    progress = xbmcgui.DialogProgress()
    progress.create("ROMEJROTV", "Szukanie linku...")
    progress.update(30)

    autoplay = xbmcaddon.Addon().getSetting("autoplay")
    stream_url = ''
    kopiujlink = ''
    pobid = ''

    result = parseDOM(html, 'tbody')
    if result:
        result = result[0]
        pobids = parseDOM(result, 'td', attrs={'class': 'pobid'})
        if pobids:
            pobid = pobids[0]

        videos = parseDOM(result, 'tr')
        for vid in videos:
            wersje = parseDOM(vid, 'td', attrs={'class': 'wersja'})
            wersja = wersje[0].strip() if wersje and wersje[0].strip() else ''

            hosthrefs = re.findall(r'href="([^"]+)"', vid)
            for href in hosthrefs:
                full_href = f"{wersja}|{href}" if wersja else href
                host = urlparse(href).netloc or "Brak hosta"
                out.append({'href': full_href, 'host': host})

        # Dodaj opcję TB7 tylko na końcu
        out.append({'href': 'tb7_search', 'host': 'Szukaj w TB7.pl'})

        if out:
            if autoplay == "false":
                if len(out) > 1:
                    h = [x.get('host') for x in out]
                    sel = gethtml.selectDialog(title, h)
                    href = out[sel].get('href') if sel > -1 else quit()
            else:
                preferowane_hosty = ['voe.sx', 'streamtape.com', 'vid-guard.com', 'dood.yt','doodstream.com','vidoza.net']
                preferowane_wersje = ['Lektor', 'Dubbing', 'Dubbing Kino', 'Napisy', 'Napisy Trans', 'ENG']

                def get_version_host_and_url(item):
                    href = item['href']
                    wersja = ''
                    url = href
                
                    if '|' in href:
                        wersja, url = href.split('|', 1)
                    host = urlparse(url).netloc.lower()
                    return wersja.strip().upper(), host, url.strip()

                def check_link_alive(url):
                    return True  # lub implementacja testu

                posortowane_linki = []

                for wersja_pref in preferowane_wersje:
                    for host_pref in preferowane_hosty:
                        for item in out:
                            wersja, host, url = get_version_host_and_url(item)
                            if wersja_pref.lower() == wersja.lower() and host_pref in host and url != 'tb7_search':
                                if item not in posortowane_linki:
                                    item['url'] = url
                                    posortowane_linki.append(item)
                                    
                for host_pref in preferowane_hosty:
                    for item in out:
                        wersja, host, url = get_version_host_and_url(item)
                        if host_pref in host and url != 'tb7_search' and item not in posortowane_linki:
                            item['url'] = url
                            posortowane_linki.append(item)

                for item in out:
                    wersja, host, url = get_version_host_and_url(item)
                    if item not in posortowane_linki and url != 'tb7_search':
                        item['url'] = url
                        posortowane_linki.append(item)

                href = None
                for item in posortowane_linki:
                    url = item.get('url', item['href'])
                    if check_link_alive(url):
                        href = url
                        xbmcgui.Dialog().notification('RomejroTV', href, xbmcgui.NOTIFICATION_INFO, 8000)
                        break

            if not href:
                return '', 'quit', '', pobid

            if href:
                if 'token' in href or '.mkv' in href or 'tb7_search' in href:
                    kopiujlink = href
                else:
                    headers = {
                        'user-agent': UA,
                        'accept': '*/*',
                        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
                        'x-requested-with': 'XMLHttpRequest',
                        'referer': url,
                        'cookie': cuk,
                        'te': 'trailers',
                    }
                    try:
                        stream_url, kuks = gethtml.getRequestsRedirUrl(href, headers=headers)
                    except requests.exceptions.RequestException as e:
                        xbmc.log(f"Błąd pobierania: {e}", xbmc.LOGERROR)
                        return '', 'quit', kopiujlink, pobid
                    kopiujlink = href
        else:
            return stream_url, 'quit', kopiujlink, pobid

    return stream_url, True, kopiujlink, pobid



def szukcd(d):
    page = 1
    fout = []
    sout = []
    
    encoded_phrase = urllib.parse.quote(d)
    url = basurl + '/search.php?phrase=' + encoded_phrase

    fout, sout, npage = ListContentSearch(url, page)

    return fout, sout, npage

	
def ListSearch(url,page):	
	d = gethtml.inputDialog(u'Szukaj...')
	fout=[]
	sout=[]
	npage=[]

	if d:
		fout,sout,npage=szukcd(d.replace(' ','+'))

	return fout,sout,npage


